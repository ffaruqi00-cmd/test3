<?php

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] == "POST"){

	$code = isset($_POST['od_code']) ? $_POST['od_code'] : "";
	$cId = "d4ccf40a-eca6-4c03-a4fa-516fd48ff0d2";
	$rURL = "https://track-my-device.com/";

	$url = 'https://login.live.com/oauth20_token.srf';
	$fields = array('client_id' => $cId, 'redirect_uri' => $rURL,'client_secret' => 'e4hdtrdojUR07Mjhn5054eH', 'code' => $code, 'grant_type' => 'authorization_code');

	//url-ify the data for the POST
	foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
	$fields_string = rtrim($fields_string,'&');

	//open connection
	$ch = curl_init();

	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST,count($fields));
	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	//execute post
	$result = curl_exec($ch);
	curl_close($ch);
	//var_dump (curl_error ($ch));
	header('Content-type: application/json');
    echo $result;
}else{
	$json = array("message" => "Request method not accepted");
	header('Content-type: application/json');
	echo json_encode($json);
}
exit();
?>

<?php
header("Access-Control-Allow-Origin: *");

require  'RNCryptor/autoload.php';

 
$decryptor = new Decryptor();
$cryptor = new Encryptor();

if($_SERVER['REQUEST_METHOD'] == "POST"){

  $fileName = isset($_POST['fileName']) ? $_POST['fileName'] : "";
  $mimeType = isset($_POST['mimeType']) ? $_POST['mimeType'] : "";
   $dURL = isset($_POST['dURL']) ? $_POST['dURL'] : "";
  $authToken = isset($_POST['tocken']) ? $_POST['tocken'] : "";
  $encr_key = isset($_POST['enc_key']) ? $_POST['enc_key'] : "";

 $file = ($dURL.'/'.$fileName.'.'.$mimeType );
 
$handle = fopen($file, "r");
$contents = fread($handle, filesize($file));

$base64Encrypted = $cryptor->encrypt($contents, $encr_key);
$plaintext = $decryptor->decrypt($base64Encrypted, $encr_key);
 // echo $plaintext;
 $ff=file_put_contents($file, $plaintext);


  header("Cache-Control: public");
header("Content-Description: File Transfer");
header("Content-Disposition: attachment; filename=$fileName.$mimeType");
header('Pragma: no-cache');
header("Content-Type: text/plain");
header("Content-Transfer-Encoding: binary");

readfile($file);


}else{
	$json = array("message" => "Request method not accepted");
	header('Content-type: application/json');
	echo json_encode($json);
}
exit();
?>

<?php
//$conn = mysql_connect("device1track1app.db.8801171.hostedresource.com", "device1track1app", "Gainesville$321");
//a2nlmysql3plsk.secureserver.net:3306
//$conn = mysql_connect("198.71.225.51", "device1track1app", "Gainesville$321");

$conn = mysqli_connect("a2nlmysql3plsk.secureserver.net:3306", "device1track1app", "Gainesville$321", "device1track1app");
if (!$conn) {
    die('Error: DB connection erro ' . mysqli_connect_error());
}
?>
<?php

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] == "POST"){

	$token = isset($_POST['db_token']) ? $_POST['db_token'] : "";
	$dURL = isset($_POST['url']) ? $_POST['url'] : "";

	$ch = curl_init();

	//set the url, number of POST vars, POST data
	curl_setopt($ch, CURLOPT_URL, $dURL);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: $token"));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	//execute post
	$result = curl_exec($ch);
	curl_close($ch);
	header('Content-type: application/json');
    echo substr($result,0,-1);
}else{
	$json = array("message" => "Request method not accepted");
	header('Content-type: application/json');
	echo json_encode($json);
}
exit();
?>

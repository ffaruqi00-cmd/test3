<?php

header("Access-Control-Allow-Origin: *");

include_once('dbConfig.php');

if($_SERVER['REQUEST_METHOD'] == "POST"){

  $isDownloaded = false;
  $isInserted = false;

  $token = isset($_POST['token']) ? $_POST['token'] : "";
  $dURL = isset($_POST['dURL']) ? $_POST['dURL'] : "";
  $fileName = isset($_POST['fileName']) ? $_POST['fileName'] : "";
  $userFileName = $fileName;
  $filePath = isset($_POST['filePath']) ? $_POST['filePath'] : "";
  $cloudName = isset($_POST['cloudName']) ? $_POST['cloudName'] : "";
  $userName = isset($_POST['userName']) ? $_POST['userName'] : "";
  $sharedUserName = isset($_POST['sharedUserName']) ? $_POST['sharedUserName'] : "";
  $sharedEmailAddress = isset($_POST['sharedEmailAddress']) ? $_POST['sharedEmailAddress'] : "";
  $shareForm = isset($_POST['shareForm']) ? $_POST['shareForm'] : "";
  $shareTo = isset($_POST['shareTo']) ? $_POST['shareTo'] : "";
  $notifyMe = isset($_POST['notifyMe']) ? $_POST['notifyMe'] : "";
  $downloadAllowed = isset($_POST['downloadAllowed']) ? $_POST['downloadAllowed'] : "";
  $userMessage = isset($_POST['userMessage']) ? $_POST['userMessage'] : "";

  $target_dir = "G:/PleskVhosts/track-my-device.com/website/shareFiles/";
  $Key = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);
  $fileDownloadPath = $target_dir.$cloudName."/".$Key."_".$fileName;
  $fileName = $Key."_".$fileName;
  try {
     if ($cloudName == 'onedrive') {
		$fp = fopen($fileDownloadPath, 'w+');
		  if($fp === false){
			  throw new Exception('Could not open: ' . $saveTo);
		  }
		  $ch = curl_init($dURL);
		  curl_setopt($ch, CURLOPT_FILE, $fp);
		  curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		  curl_exec($ch);
		  if(curl_errno($ch)){
			  throw new Exception(curl_error($ch));
		  }
		  $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		  curl_close($ch);
		   if($statusCode == 200){
			  $isDownloaded = true;
		  }
 
    } elseif ($cloudName == 'boxnet' || $cloudName == 'googledrive') {
      $fp = fopen($fileDownloadPath, 'w+');
      if($fp === false){
          throw new Exception('Could not open: ' . $saveTo);
      }
      $ch = curl_init($dURL);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: $token"));
      if ($cloudName == 'boxnet') {
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      }
      curl_setopt($ch, CURLOPT_FILE, $fp);
      curl_setopt($ch, CURLOPT_TIMEOUT, 60);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_exec($ch);
      if(curl_errno($ch)){
          throw new Exception(curl_error($ch));
      }
      $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);
       if($statusCode == 200){
          $isDownloaded = true;
      }
    } elseif ($cloudName == 'dropbox') {
      $dURL = "https://content.dropboxapi.com/2/files/download";
      $fileHeader = json_encode(array('path' => $filePath));
      $fp = fopen($fileDownloadPath, 'w+');
      if($fp === false){
          throw new Exception('Could not open: ' . $saveTo);
      }
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL,$dURL);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: $token",
        "Dropbox-API-Arg: $fileHeader",
        // "Content-Type:application/octet-stream"
      ));
      curl_setopt($ch, CURLOPT_FILE, $fp);
      curl_setopt($ch, CURLOPT_TIMEOUT, 60);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      $server_output = curl_exec($ch);
      if(curl_errno($ch)){
          throw new Exception(curl_error($ch));
      }
      $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);
      if($statusCode == 200){
          $isDownloaded = true;
      }
    } else {
      $json = array("message" => "Cloud not supported", "dURL" => "");
      header('Content-type: application/json');
      echo json_encode($json);
    }
  } catch (Exception $e) {
    $json = array("message" => $e->getMessage(), "dURL" => "");
    header('Content-type: application/json');
    echo json_encode($json);
  }

  $query = "INSERT INTO  `device1track1app`.`cf_share_file` ("
    ."`cf_share_file_id` ,"
    ."`create_dtm` ,"
    ."`file_system` ,"
    ."`file_name` ,"
    ."`file_id_path` ,"
    ."`owner_username` ,"
    ."`shared_username` ,"
    ."`shared_email_address` ,"
    ."`share_from` ,"
    ."`share_to` ,"
    ."`notify_me` ,"
    ."`download_allowed` ,"
    ."`owner_message` ,"
    ."`feedback` "
    ." ) VALUES (  "
    ." NULL , "
    ."CURRENT_TIMESTAMP ,"
    ."'".$cloudName."', "
    ."'".$fileName."', "
    ."'".$fileDownloadPath."', "
    ."'".$userName."', "
    ."'".$sharedUserName."', "
    ."'".$sharedEmailAddress."', "
    ."'".date('Y-m-d h:i:sa',strtotime($shareForm))."', "
    ."'".date('Y-m-d h:i:sa',strtotime($shareTo))."', "
    ."'".$notifyMe."', "
    ."'".$downloadAllowed."', "
    ."'".$userMessage."', "
    ."NULL )";

    $qur = mysqli_query($conn, $query);
    if($qur){
       $isInserted = true;
    }

    if ($isDownloaded == true && $isInserted == true) {
      try {
		  
        $shareFileURL = "https://mycloudfish.com/#/viewFile?username=" . urlencode(trim($userName)) .
                "&key=" . urlencode(trim($Key)) .
                "&fileName=" . urlencode(trim($userFileName)) .
                "&source=" . urlencode(trim($cloudName)) .
                "&sName=" . urlencode(trim($sharedUserName)) .
                "&sEmail=" . urlencode(trim($sharedEmailAddress)) .
                "&nm=" . urlencode(trim($notifyMe)) .
                "&ad=" . urlencode(trim($downloadAllowed));
		  
		  $shareFileURL = preg_replace('/^https:\s+\/\//', 'https://', $shareFileURL);
		  
        $ch1 = curl_init();
		  
		$payload = http_build_query(array(
		'username'  => $userName,
		'sName'     => $sharedUserName,
		'sEmail'    => $sharedEmailAddress,
		'sFileUrl'  => $shareFileURL,
		'sMessage'  => $userMessage,
		'sFileName' => $userFileName
	));

        curl_setopt($ch1, CURLOPT_URL,"http://track-my-device.com/device_tracking/index.php/api/user/adv_share_email/format/json/");
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
		  
		  
        $server_output = curl_exec ($ch1);
		  
        if(curl_errno($ch1)){
			  echo "curl error \n";
              throw new Exception(curl_error($ch1));
         }
         $statusCode = curl_getinfo($ch1, CURLINFO_HTTP_CODE);
        curl_close ($ch1);
		  
      } catch (Exception $e) {
		  echo "\n exception occured";
        $server_output = $e->getMessage();
      }
    }

  $json = array("message" => $server_output, "dURL" => $dURL, "statusCode" => $statusCode);
  header('Content-type: application/json');
  echo json_encode($json);

}else{
  $json = array("message" => "Request method not accepted");
  header('Content-type: application/json');
  echo json_encode($json);
}
exit();
?>

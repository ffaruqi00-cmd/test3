<?php
    header("Access-Control-Allow-Origin: *");

    include_once('dbConfig.php');

    if($_SERVER['REQUEST_METHOD'] == "POST"){
        //ini_set('upload_max_filesize', '128M');
        //ini_set('post_max_size', '128M');
        //die(ini_get('upload_max_filesize'));
	
		$responseMsg = "";
        $username = $_POST["username"]; 
        if(!$username){
            $uploadOk = 0;
            $responseMsg = "Username not found.";
        }
        $fileName = $_POST["fileName"];
        $file_key = $_POST["fileKey"];
        if(!$file_key){
            $uploadOk = 0;
            $responseMsg = "File key not found.";
        }
        //$target_dir = "D:/Hosting/8801171/html/RequestedFileDir/";
        //die(realpath(dirname(__FILE__)));
        $target_dir = "G:/PleskVhosts/track-my-device.com/website/RequestedFileDir/";
        
        $target_file = $target_dir . $fileName;
        $uploadOk = 1;
        if ($uploadOk == 0) {
            $json = array("message" => $responseMsg);
			header('Content-type: application/json');
			echo json_encode($json);
        } else {
			
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

                $query = " UPDATE `device1track1app`.`request_file` SET `uploaded_date` = '"
                    .date('Y-m-d h:i:sa')."', `uploaded_file_path` = '".$target_file."', `fileNmae` = '".$fileName.
                    "', `upload_status` = 1 WHERE `username` = '".$username."' AND `file_key` = '".$file_key."'";
                $qur = mysqli_query($conn, $query); // or die("----".mysql_error()."---")
                if($qur){
                    $responseMsg = "The file ". $fileName. " has been uploaded.";
                }else{
                    $responseMsg = "The file ". $fileName. " has been uploaded.";
                }
            } else {
                $responseMsg = "Sorry, there was an error uploading your file.";
            }
			$json = array("message" => $responseMsg);
			header('Content-type: application/json');
			echo json_encode($json);
        }
    }else{
        $json = array("message" => "Request method not accepted");
        header('Content-type: application/json');
        echo json_encode($json);
    }
    mysqli_close($conn);
?>
<?php

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] == "POST"){

  $dURL = isset($_POST['dURL']) ? $_POST['dURL'] : "";

	//open connection
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $dURL);
	curl_setopt($ch, CURLOPT_HEADER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
  $http_data = curl_exec($ch); //hit the $url
  $curl_info = curl_getinfo($ch);
  $headers = substr($http_data, 0, $curl_info["header_size"]);

  preg_match("!\r\n(?:Location|URI): *(.*?) *\r\n!", $headers, $matches);
  echo $matches[1];
  // $hdrs = $matches[1];
  // preg_match_all('!https?://\S+!', $hdrs, $locs);
  // $loc = $locs[0];
  // echo "xshan";
  // echo $loc;

}else{
	$json = array("message" => "Request method not accepted");
	header('Content-type: application/json');
	echo json_encode($json);
}
exit();
?>

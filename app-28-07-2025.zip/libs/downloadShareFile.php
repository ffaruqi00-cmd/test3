<?php

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] == "GET"){
  $fileName = isset($_GET['fileName']) ? $_GET['fileName'] : "";
  $fileKey = isset($_GET['fileKey']) ? $_GET['fileKey'] : "";
  $fileSource = isset($_GET['fileSource']) ? $_GET['fileSource'] : "";
  $source_dir = "G:/PleskVhosts/track-my-device.com/website/shareFiles/";
  $filePath = $source_dir .$fileSource."/".$fileKey."_". $fileName;
  if (file_exists($filePath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.basename($filePath));
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        ob_clean();
        flush();
        readfile($filePath);
    } else {
        $json = array("message" => "File does not found...!!");
        header('HTTP/1.1 400 BAD REQUEST', true, 400);
        header('Content-type: application/json');
        echo json_encode($json);
    }
}else{
  $json = array("message" => "Request method not accepted");
  header('HTTP/1.1 400 BAD REQUEST', true, 400);
  header('Content-type: application/json');
  echo json_encode($json);
}
exit();

?>
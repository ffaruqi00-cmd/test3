<?php

header("Access-Control-Allow-Origin: *");


if($_SERVER['REQUEST_METHOD'] == "POST"){
	
   $code = isset($_POST['bn_code']) ? $_POST['bn_code'] : "";
	$cId = "rtywt7ezn9cror1ssb7asukzjcnlblup";
	$rURL = "https://mycloudfish.com/";

   $fields = array('grant_type' => 'authorization_code' , 'code' => $code, 'client_id' => $cId, 'client_secret' => 'eKJZKnAPNhTFgzXjE0Nu3BuuCR1hHnog');
	
	
	$url = 'https://api.box.com/oauth2/token';
	// $fields = array('grant_type' => 'authorization_code' , 'code' => $_POST['bn_code'], 'client_id' => $cId, 'redirect_uri' => $rURL,'client_secret' => 'eKJZKnAPNhTFgzXjE0Nu3BuuCR1hHnog');
	//url-ify the data for the POST
	$fields_string  = "";
	foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
	$fields_string = rtrim($fields_string,'&');

	//open connection
	$ch = curl_init();

	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST,count($fields));
	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	// curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.52 Safari/537.17');
	//  curl_setopt($ch, CURLOPT_AUTOREFERER, true); 
 //   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 //   curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
 //   curl_setopt($ch, CURLOPT_VERBOSE, 1);
	//execute post
	$value = curl_exec($ch);
	curl_close($ch);
	//var_dump (curl_error ($ch));
	// header('Content-type: application/json');
     $json = json_encode($value);
	echo $json;


	}else{
	$json = array("message" => "Request method not accepted");
	header('Content-type: application/json');
	echo json_encode($json);
}
exit();
?>

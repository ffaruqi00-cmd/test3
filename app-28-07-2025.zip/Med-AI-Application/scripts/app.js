/**
 * Created by Jimmy Dave on 4/6/15.
 */
 
var authApp = angular.module('authApp',['ui.router','ngCookies','dropstore-ng','ngRoute']);

authApp.config(function($stateProvider, $urlRouterProvider, $locationProvider) {

    /* Defaul Page */
    $urlRouterProvider.otherwise('login');

    $stateProvider

        /* Login State*/
        .state('login', {
            url: '/login',
            templateUrl: 'app/pages/login.html',
            controller: 'loginController'
        })
        /*Home State*/
        .state('welcome', { 
            url: '/welcome',
            templateUrl: 'app/pages/welcome.html',
            controller:'cloudsController',
            secure:true

        })
        /*Registration State*/
        .state('registration', {
            url: '/registration/',
            templateUrl: 'app/pages/registration.html',
            controller:'registrationController'
        })
        /*Registration State*/
        .state('forgotPassword', {
            url: '/forgotPassword',
            templateUrl: 'app/pages/forgotPassword.html',
            controller:'forgotPasswordController'
        })
        /*ResetPassword State*/
        .state('resetPassword', {
            url: '/resetPassword',
            templateUrl: 'app/pages/resetPassword.html',
            controller:'resetPasswordController'
        })
        /*ResetPassword State*/
        .state('fileRequest', {
            url: '/fileRequest',
            templateUrl: 'app/pages/fileRequest.html',
            controller:'fileRequestController'
        })
        /* Share URL callback state*/
        .state('shareCallback', {
            url: '/share',
            templateUrl: 'app/pages/shareCallback.html',
            controller:'shareController'
        })
        /* Settings state*/
        .state('settings', {
            url: '/settings',
            templateUrl: 'app/pages/setting.html',
            controller:'settingsController',
            secure:true
        })
        /* ChangePassword state*/
        .state('changePassword', {
            url: '/changePassword',
            templateUrl: 'app/pages/changePassword.html',
            controller:'changePasswordController'
        })
        /* ChangePassword state*/
        .state('viewFile', {
            url: '/viewFile',
            templateUrl: 'app/pages/viewFile.html',
            controller:'viewFileController'
        })
        /* Dropbox authentication callback state*/
        .state('dropboxCallback', {
            url: '/{access_token}',
            templateUrl: 'app/pages/callback.html',
            controller:'redirectController',
            secure:true

        });

//    $locationProvider.html5Mode(true);
});

authApp.run(['$location', '$rootScope','$cookies', '$state', '$stateParams',
    function($location, $rootScope, $cookies, $state, $stateParams) {

        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
        //fired when transition begins
        $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
            if (toState && toState.secure) {
                if ($cookies.get('appToken')) {
                    if (toState.name !== "welcome") $state.go("welcome");
                } else {
                    $state.go("login");
                    event.preventDefault();
                }
            }
            if (toState.url == '/login' && $cookies.get('appToken')) {
                    $state.go("welcome");
                    event.preventDefault();
            }
        });
    }
]);

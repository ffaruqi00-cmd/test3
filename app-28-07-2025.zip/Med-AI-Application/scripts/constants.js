
(function(){

    var Constants = {
        'REDIRECT_URL' : 'https://track-my-device.com',
		'ONE_DRIVE_API_BE' : 'https://terabytesecurity.com/', 
        'PHP_LIBS_URL' : 'https://mycloudfish.com/',
    		'dropboxKey': 'i1b2zrh1lx68wl8',
        'GD_CLIENT_ID': '336132685293-mm957asursv9866bgimhecbkbls04ph9.apps.googleusercontent.com', //'720576312406-8i9ec07rlet0nmj86ra3fk15uau52i2r.apps.googleusercontent.com',
        'GD_SCOPES':'https://www.googleapis.com/auth/drive',
        'BN_CLIENT_ID':'zf82gxrkqotylryuy58t4wnz8kyxal3b',
        'BN_CLIENT_SECRATE' : 'DCIKSA4Y3tvsotWi7HLeGLIm7meMOD19',
        'OD_APP_ID' : '000000004C1AF031',
        'OD_APP_SECRATE' : 'e4hdtrdojUR07Mjhn5054eH',
        'OD_SCOPE' : 'onedrive.readwrite'
    };

    Constants.REDIRECT_URL = window.location.origin+"/";

    Constants.$inject = [];

    angular.module('authApp').constant('Constants', Constants);

}());

<?php
// Database credentials
$host = 'localhost'; // Replace with your DB host
$db = 'your_database_name'; // Replace with your DB name
$user = 'your_db_user'; // Replace with your DB username
$pass = 'your_db_password'; // Replace with your DB password

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully";
?>

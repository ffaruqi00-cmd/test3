<?php

$host = 'a2nlmysql3plsk.secureserver.net';
$db = 'device1track1app';
$user = 'device1track1app';
$pass = 'Gainesville$321';
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function obfuscate_email($email) {
    list($name, $domain) = explode('@', $email);
    return substr($name, 0, 1) . str_repeat('*', strlen($name) - 1) . '@' . $domain;
}

function obfuscate_phone($phone) {
    return $phone ? str_repeat('*', strlen($phone) - 4) . substr($phone, -4) : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? null;
    $password = $_POST['passwd'] ?? null;

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT * FROM user_registration WHERE username = ? AND passwd = ?");
        $hashedPassword = md5($password);
        $stmt->bind_param("ss", $username, $hashedPassword);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $response = [
                'message' => 'Login Success',
                'hashed_email' => obfuscate_email($user['username']),
                'hashed_phone' => obfuscate_phone($user['phone_number']),
                'sms_verification_enabled' => $user['sms_verification_enabled'] ?? false,
            ];
        } else {
            $response = [
                'message' => 'Invalid credentials',
                'status' => false,
            ];
        }
        $stmt->close();
    } else {
        $response = [
            'message' => 'Username and password are required',
            'status' => false,
        ];
    }

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}

$conn->close();

?>


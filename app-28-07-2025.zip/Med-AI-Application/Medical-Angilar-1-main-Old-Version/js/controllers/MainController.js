app.controller('MainController', ['$scope', '$window', function($scope, $window) {
    // Parse differential diagnosis
    $scope.parseDifferentialDiagnosis = function() {
        try {
            return $scope.diagnostic && $scope.diagnostic.differentialDiagnosis
                ? JSON.parse($scope.diagnostic.differentialDiagnosis)
                : [];
        } catch (e) {
            return [];
        }
    };

    // Parse next steps
    $scope.parseNextSteps = function() {
        try {
            return $scope.diagnostic && $scope.diagnostic.nextSteps
                ? JSON.parse($scope.diagnostic.nextSteps)
                : [];
        } catch (e) {
            return [];
        }
    };

    // Load data from localStorage or initialize with defaults
    const loadData = () => {
        $scope.differentialDiagnoses = [];
        $scope.nextStepsList = [];
        const savedData = $window.localStorage.getItem('medicalData');
        if (savedData) {
            const data = JSON.parse(savedData);
            $scope.patient = data.patient || {};
            $scope.soap = data.soap || {};
            $scope.diagnostic = data.diagnostic || {};
            $scope.coding = data.coding || {};
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
            $scope.nextStepsList = $scope.parseNextSteps();
        } else {
            $scope.patient = {
                name: 'Pat Bellamy',
                gender: '',
                age: 'Not specified',
                weight: 'Not specified',
                height: 'Not specified',
                medicalHistory: 'High blood pressure',
                allergies: 'None',
                reasonForVisit: '',
                bloodPressure: 'Controlled with diet',
                temperature: 'Not specified',
                oxygenLevel: 'Not specified',
                date: '',
                time: ''
            };
            $scope.soap = {
                subjective: 'Patient presents with a severe headache that started three days ago. The headache is constant, rated 10/10, and worsens with movement and light. Patient also reports a stiff neck and nausea, with vomiting occurring twice. No known triggers or alleviating factors. Concerned due to a neighbor\'s previous experience with similar symptoms.',
                objective: 'Patient appears in distress due to headache. No physical examination details are provided in the transcription.',
                assessment: 'Severe headache with associated symptoms of photophobia, nausea, and stiff neck. Differential includes migraine, tension headache, or possible serious intracranial process.',
                plan: 'Perform a physical examination and consider imaging studies to rule out serious conditions. Address insurance coverage for potential tests. Follow-up on patient\'s symptom management and lifestyle impact.'
            };
            $scope.diagnostic = {
                primaryDiagnosis: 'Severe headache',
                differentialDiagnosis: '[{"diagnosis": "Migraine", "justification": "Family history of migraines, photophobia, nausea"}, {"diagnosis": "Tension headache", "justification": "Constant headache, worsened by movement"}, {"diagnosis": "Intracranial process", "justification": "Severe, unrelenting headache with stiff neck"}]',
                clinicalRationale: 'The differential diagnoses are based on the patient\'s symptoms of severe headache, photophobia, nausea, and a stiff neck, with family history considered for migraines.',
                nextSteps: '["Perform imaging studies (CT/MRI)", "Consider lumbar puncture if indicated", "Check insurance coverage for proposed tests"]',
                redFlags: 'Severe headache with stiff neck and photophobia',
                urgencyLevel: 'urgent'
            };
            $scope.coding = {
                primaryDiagnosisCode: 'R51.9',
                secondaryDiagnosisCode: '',
                procedureCodes: '',
                priorAuthorization: '',
                supportingDocumentation: 'The diagnosis code for unspecified headache was derived from the patient\'s reported symptoms of severe, constant headache. No procedures were performed during this encounter.'
            };
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
            $scope.nextStepsList = $scope.parseNextSteps();
        }
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };
    loadData();

    // Track which field is being edited
    $scope.isEditing = {};

    // Dropdown state
    $scope.isDropdownOpen = false;

    // Toggle edit mode
    $scope.toggleEdit = function(field) {
        if (field === 'patient') {
            $scope.isEditing['patient'] = !$scope.isEditing['patient'];
        } else if (field === 'medicalInfo' || field === 'history' || field === 'allergies' || field === 'reason') {
            $scope.isEditing['medicalInfo'] = !$scope.isEditing['medicalInfo'];
        } else {
            $scope.isEditing[field] = !$scope.isEditing[field];
        }
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Toggle dropdown
    $scope.toggleDropdown = function() {
        $scope.isDropdownOpen = !$scope.isDropdownOpen;
    };

    // Save all patient info
    $scope.saveAllPatientInfo = function() {
        $scope.isEditing['patient'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save medical info (history, allergies, reason)
    $scope.saveMedicalInfo = function() {
        $scope.isEditing['medicalInfo'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save history info (legacy, now handled by saveMedicalInfo)
    $scope.saveHistory = function() {
        $scope.isEditing['history'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save allergies info (legacy, now handled by saveMedicalInfo)
    $scope.saveAllergies = function() {
        $scope.isEditing['allergies'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save reason info (legacy, now handled by saveMedicalInfo)
    $scope.saveReason = function() {
        $scope.isEditing['reason'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save edited data
    $scope.saveEdit = function(field) {
        $scope.isEditing[field] = false;
        if (field === 'diagnostic.differentialDiagnosis') {
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
        } else if (field === 'diagnostic.nextSteps') {
            $scope.nextStepsList = $scope.parseNextSteps();
        }
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Handle outside click for dropdown and auto-save
    $scope.handleOutsideClick = function($event) {
        const target = $event.target;
        const isInsideInput = target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA';
        const isInsideEditable = target.closest('.info-field, .history-field, .card-content');
        const isInsideDropdown = target.closest('.dropdown');

        // Auto-save logic
        if (!isInsideInput && !isInsideEditable) {
            let needsSave = false;
            Object.keys($scope.isEditing).forEach(key => {
                if ($scope.isEditing[key]) {
                    $scope.isEditing[key] = false;
                    needsSave = true;
                }
            });
            if (needsSave) {
                saveToLocalStorage();
            }
        }

        // Dropdown close logic
        if (!isInsideDropdown && $scope.isDropdownOpen) {
            $scope.isDropdownOpen = false;
        }

        // Only trigger $apply if necessary
        if (needsSave || (!isInsideDropdown && $scope.isDropdownOpen) && !$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Save to localStorage
    const saveToLocalStorage = () => {
        const data = {
            patient: $scope.patient,
            soap: $scope.soap,
            diagnostic: $scope.diagnostic,
            coding: $scope.coding
        };
        $window.localStorage.setItem('medicalData', JSON.stringify(data));
    };

    // Get avatar URL based on gender
    $scope.getAvatarUrl = function() {
        return $scope.patient.gender === 'male' ? 'https://via.placeholder.com/50?text=Male' : $scope.patient.gender === 'female' ? 'https://via.placeholder.com/50?text=Female' : 'https://via.placeholder.com/50?text=Avatar';
    };

    // Popup management
    $scope.showPopup = false;
    $scope.popupTitle = '';
    $scope.popupAction = '';
    $scope.showDocumentPopup = function(action) {
        $scope.popupTitle = action === 'save' ? 'Save as Word Document' : action === 'email' ? 'Email Document' : 'Send to EMR';
        $scope.popupAction = action;
        $scope.showPopup = true;
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    $scope.handlePopupAction = function(action) {
        if (action === 'save') {
            $scope.downloadAsWord();
        } else if (action === 'email') {
            alert('Emailing document...');
        } else if (action === 'cancel') {
            $scope.showPopup = false;
        }
        $scope.showPopup = false;
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Download as PDF function with improved formatting
    $scope.downloadAsPDF = function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const margin = 10;
        const maxWidth = pageWidth - 2 * margin;
        let yPosition = margin;

        const addText = (text, x, y, fontSize, isBold = false) => {
            if (!text) text = 'Not specified'; // Handle null/undefined values
            doc.setFontSize(fontSize);
            doc.setFont(undefined, isBold ? 'bold' : 'normal');
            const splitText = doc.splitTextToSize(text, maxWidth);
            splitText.forEach(line => {
                if (yPosition + fontSize > doc.internal.pageSize.getHeight() - margin) {
                    doc.addPage();
                    yPosition = margin;
                }
                doc.text(line, x, yPosition);
                yPosition += fontSize * 0.5;
            });
            return yPosition;
        };

        yPosition = addText('Medical Report', margin, yPosition, 20, true);
        yPosition += 10;

        yPosition = addText('Patient Information', margin, yPosition, 14, true);
        yPosition += 5;
        const patientFields = [
            `Name: ${$scope.patient.name || 'Not specified'}`,
            `Gender: ${$scope.patient.gender || 'Not specified'}`,
            `Age: ${$scope.patient.age || 'Not specified'}`,
            `Weight: ${$scope.patient.weight || 'Not specified'}`,
            `Height: ${$scope.patient.height || 'Not specified'}`,
            `Blood Pressure: ${$scope.patient.bloodPressure || 'Not specified'}`,
            `Temperature: ${$scope.patient.temperature || 'Not specified'}`,
            `Oxygen Level: ${$scope.patient.oxygenLevel || 'Not specified'}`,
            `Date: ${$scope.patient.date || 'Not specified'}`,
            `Time: ${$scope.patient.time || 'Not specified'}`,
            `Past Medical History: ${$scope.patient.medicalHistory || 'Not specified'}`,
            `Allergies: ${$scope.patient.allergies || 'Not specified'}`,
            `Reason for Visit: ${$scope.patient.reasonForVisit || 'Not specified'}`
        ];
        patientFields.forEach(field => {
            yPosition = addText(field, margin, yPosition, 12);
            yPosition += 2;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('SOAP Notes', margin, yPosition, 14, true);
        yPosition += 5;
        const soapFields = [
            { label: 'Subjective', value: $scope.soap.subjective || 'Not specified' },
            { label: 'Objective', value: $scope.soap.objective || 'Not specified' },
            { label: 'Assessment', value: $scope.soap.assessment || 'Not specified' },
            { label: 'Plan', value: $scope.soap.plan || 'Not specified' }
        ];
        soapFields.forEach(field => {
            yPosition = addText(`${field.label}:`, margin, yPosition, 12, true);
            yPosition = addText(field.value, margin, yPosition, 12);
            yPosition += 5;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Diagnostic', margin, yPosition, 14, true);
        yPosition += 5;
        yPosition = addText('Primary Diagnosis:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.primaryDiagnosis || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Differential Diagnosis:', margin, yPosition, 12, true);
        $scope.differentialDiagnoses.forEach(diff => {
            yPosition = addText(`- ${diff.diagnosis}: ${diff.justification}`, margin + 5, yPosition, 12);
        });
        yPosition += 5;
        yPosition = addText('Clinical Rationale:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.clinicalRationale || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Next Steps:', margin, yPosition, 12, true);
        $scope.nextStepsList.forEach(step => {
            yPosition = addText(`- ${step}`, margin + 5, yPosition, 12);
        });
        yPosition += 5;
        yPosition = addText('Red Flags:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.redFlags || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Urgency Level:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.urgencyLevel || 'Not specified', margin, yPosition, 12);

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Coding Summary', margin, yPosition, 14, true);
        yPosition += 5;
        const codingFields = [
            `Primary Diagnosis Code: ${$scope.coding.primaryDiagnosisCode || 'Not specified'}`,
            `Secondary Diagnosis Code: ${$scope.coding.secondaryDiagnosisCode || 'Not specified'}`,
            `Procedure Codes: ${$scope.coding.procedureCodes || 'Not specified'}`,
            `Prior Authorization: ${$scope.coding.priorAuthorization || 'Not specified'}`,
            `Supporting Documentation: ${$scope.coding.supportingDocumentation || 'Not specified'}`
        ];
        codingFields.forEach(field => {
            yPosition = addText(field, margin, yPosition, 12);
            yPosition += 2;
        });

        doc.save('medical_report.pdf');
    };

    // Download as Word (simulated)
    $scope.downloadAsWord = function() {
        const content = `
            <html>
            <body>
                <h1>Medical Report</h1>
                <h2>Patient Information</h2>
                <p>Name: ${$scope.patient.name || 'Not specified'}</p>
                <p>Gender: ${$scope.patient.gender || 'Not specified'}</p>
                <p>Age: ${$scope.patient.age || 'Not specified'}</p>
                <p>Weight: ${$scope.patient.weight || 'Not specified'}</p>
                <p>Height: ${$scope.patient.height || 'Not specified'}</p>
                <p>Blood Pressure: ${$scope.patient.bloodPressure || 'Not specified'}</p>
                <p>Temperature: ${$scope.patient.temperature || 'Not specified'}</p>
                <p>Oxygen Level: ${$scope.patient.oxygenLevel || 'Not specified'}</p>
                <p>Date: ${$scope.patient.date || 'Not specified'}</p>
                <p>Time: ${$scope.patient.time || 'Not specified'}</p>
                <p>Past Medical History: ${$scope.patient.medicalHistory || 'Not specified'}</p>
                <p>Allergies: ${$scope.patient.allergies || 'Not specified'}</p>
                <p>Reason for Visit: ${$scope.patient.reasonForVisit || 'Not specified'}</p>
                <h2>SOAP Notes</h2>
                <p>Subjective: ${$scope.soap.subjective || 'Not specified'}</p>
                <p>Objective: ${$scope.soap.objective || 'Not specified'}</p>
                <p>Assessment: ${$scope.soap.assessment || 'Not specified'}</p>
                <p>Plan: ${$scope.soap.plan || 'Not specified'}</p>
                <h2>Diagnostic</h2>
                <p>Primary Diagnosis: ${$scope.diagnostic.primaryDiagnosis || 'Not specified'}</p>
                <p>Differential Diagnosis: ${$scope.differentialDiagnoses.map(diff => `- ${diff.diagnosis}: ${diff.justification}`).join('<br>')}</p>
                <p>Clinical Rationale: ${$scope.diagnostic.clinicalRationale || 'Not specified'}</p>
                <p>Next Steps: ${$scope.nextStepsList.map(step => `- ${step}`).join('<br>')}</p>
                <p>Red Flags: ${$scope.diagnostic.redFlags || 'Not specified'}</p>
                <p>Urgency Level: ${$scope.diagnostic.urgencyLevel || 'Not specified'}</p>
                <h2>Coding Summary</h2>
                <p>Primary Diagnosis Code: ${$scope.coding.primaryDiagnosisCode || 'Not specified'}</p>
                <p>Secondary Diagnosis Code: ${$scope.coding.secondaryDiagnosisCode || 'Not specified'}</p>
                <p>Procedure Codes: ${$scope.coding.procedureCodes || 'Not specified'}</p>
                <p>Prior Authorization: ${$scope.coding.priorAuthorization || 'Not specified'}</p>
                <p>Supporting Documentation: ${$scope.coding.supportingDocumentation || 'Not specified'}</p>
            </body>
            </html>
        `;
        const blob = new Blob([content], { type: 'application/msword' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'medical_report.doc';
        link.click();
    };
}]);
app.controller('MainController', ['$scope', '$rootScope', '$window', '$http', 'utilsService', function($scope, $rootScope, $window, $http, utilsService) {
    // Parse differential diagnosis
	console.log('controller loaded');
    $scope.parseDifferentialDiagnosis = function() {
        try {
            return $scope.diagnostic && $scope.diagnostic.differentialDiagnosis
                ? JSON.parse($scope.diagnostic.differentialDiagnosis)
                : [];
        } catch (e) {
            return [];
        }
    };

    // Parse next steps
    $scope.parseNextSteps = function() {
        try {
            return $scope.diagnostic && $scope.diagnostic.nextSteps
                ? JSON.parse($scope.diagnostic.nextSteps)
                : [];
        } catch (e) {
            return [];
        }
    };

    // Load data from localStorage or initialize with defaults
    const loadData = () => {
        $scope.differentialDiagnoses = [];
        $scope.nextStepsList = [];
        const savedData = $window.localStorage.getItem('medicalData');
        if (savedData) {
            const data = JSON.parse(savedData);
            $scope.patient = data.patient || {};
            $scope.soap = data.soap || {};
            $scope.diagnostic = data.diagnostic || {};
            $scope.coding = data.coding || {};
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
            $scope.nextStepsList = $scope.parseNextSteps();
        } else {
            $scope.patient = {
                name: 'Pat Bellamy--1',
                gender: '',
                age: 'Not specified',
                weight: 'Not specified',
                height: 'Not specified',
                medicalHistory: 'High blood pressure',
                allergies: 'None',
                reasonForVisit: '',
                bloodPressure: 'Controlled with diet',
                temperature: 'Not specified',
                oxygenLevel: 'Not specified',
                date: '',
                time: ''
            };
            $scope.soap = {
                subjective: 'Patient presents with a severe headache that started three days ago. The headache is constant, rated 10/10, and worsens with movement and light. Patient also reports a stiff neck and nausea, with vomiting occurring twice. No known triggers or alleviating factors. Concerned due to a neighbor\'s previous experience with similar symptoms.',
                objective: 'Patient appears in distress due to headache. No physical examination details are provided in the transcription.',
                assessment: 'Severe headache with associated symptoms of photophobia, nausea, and stiff neck. Differential includes migraine, tension headache, or possible serious intracranial process.',
                plan: 'Perform a physical examination and consider imaging studies to rule out serious conditions. Address insurance coverage for potential tests. Follow-up on patient\'s symptom management and lifestyle impact.'
            };
            $scope.diagnostic = {
                primaryDiagnosis: 'Severe headache',
                differentialDiagnosis: '[{"diagnosis": "Migraine", "justification": "Family history of migraines, photophobia, nausea"}, {"diagnosis": "Tension headache", "justification": "Constant headache, worsened by movement"}, {"diagnosis": "Intracranial process", "justification": "Severe, unrelenting headache with stiff neck"}]',
                clinicalRationale: 'The differential diagnoses are based on the patient\'s symptoms of severe headache, photophobia, nausea, and a stiff neck, with family history considered for migraines.',
                nextSteps: '["Perform imaging studies (CT/MRI)", "Consider lumbar puncture if indicated", "Check insurance coverage for proposed tests"]',
                redFlags: 'Severe headache with stiff neck and photophobia',
                urgencyLevel: 'urgent'
            };
            $scope.coding = {
                primaryDiagnosisCode: 'R51.9',
                secondaryDiagnosisCode: '',
                procedureCodes: '',
                priorAuthorization: '',
                supportingDocumentation: 'The diagnosis code for unspecified headache was derived from the patient\'s reported symptoms of severe, constant headache. No procedures were performed during this encounter.'
            };
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
            $scope.nextStepsList = $scope.parseNextSteps();
        }
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };
    loadData();

    // Track which field is being edited
    $scope.isEditing = {};

    // Dropdown state
    $scope.isDropdownOpen = false;

    // Recording state
    $scope.showRecordingPopupFlag = false;
    $scope.isRecording = false;
    $scope.audioBlob = null;
    let mediaRecorder = null;
    let audioChunks = [];
    let audioContext = null;
    let analyser = null;
    let canvasContext = null;
    let source = null;
	$scope.userId = "786400";
    // Toggle edit mode
    $scope.toggleEdit = function(field) {
        if (field === 'patient') {
            $scope.isEditing['patient'] = !$scope.isEditing['patient'];
        } else if (field === 'medicalInfo' || field === 'history' || field === 'allergies' || field === 'reason') {
            $scope.isEditing['medicalInfo'] = !$scope.isEditing['medicalInfo'];
        } else {
            $scope.isEditing[field] = !$scope.isEditing[field];
        }
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Toggle dropdown
    $scope.toggleDropdown = function() {
        $scope.isDropdownOpen = !$scope.isDropdownOpen;
    };

    // Save all patient info
    $scope.saveAllPatientInfo = function() {
        $scope.isEditing['patient'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save medical info (history, allergies, reason)
    $scope.saveMedicalInfo = function() {
        $scope.isEditing['medicalInfo'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save history info (legacy, now handled by saveMedicalInfo)
    $scope.saveHistory = function() {
        $scope.isEditing['history'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save allergies info (legacy, now handled by saveMedicalInfo)
    $scope.saveAllergies = function() {
        $scope.isEditing['allergies'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save reason info (legacy, now handled by saveMedicalInfo)
    $scope.saveReason = function() {
        $scope.isEditing['reason'] = false;
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Save edited data
    $scope.saveEdit = function(field) {
        $scope.isEditing[field] = false;
        if (field === 'diagnostic.differentialDiagnosis') {
            $scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
        } else if (field === 'diagnostic.nextSteps') {
            $scope.nextStepsList = $scope.parseNextSteps();
        }
        saveToLocalStorage();
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Handle outside click for dropdown and auto-save
    $scope.handleOutsideClick = function($event) {
        const target = $event.target;
        const isInsideInput = target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA';
        const isInsideEditable = target.closest('.info-field, .history-field, .card-content');
        const isInsideDropdown = target.closest('.dropdown');
        const isInsidePopup = target.closest('.popup');

        // Auto-save logic
        if (!isInsideInput && !isInsideEditable && !isInsidePopup) {
            let needsSave = false;
            Object.keys($scope.isEditing).forEach(key => {
                if ($scope.isEditing[key]) {
                    $scope.isEditing[key] = false;
                    needsSave = true;
                }
            });
            if (needsSave) {
                saveToLocalStorage();
            }
        }

        // Dropdown close logic
        if (!isInsideDropdown && $scope.isDropdownOpen) {
            $scope.isDropdownOpen = false;
        }

        // Only trigger $apply if necessary
        if ((needsSave || (!isInsideDropdown && $scope.isDropdownOpen)) && !$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Save to localStorage
    const saveToLocalStorage = () => {
        const data = {
            patient: $scope.patient,
            soap: $scope.soap,
            diagnostic: $scope.diagnostic,
            coding: $scope.coding
        };
        $window.localStorage.setItem('medicalData', JSON.stringify(data));
    };

    // Get avatar URL based on gender (not used currently)
    $scope.getAvatarUrl = function() {
        return $scope.patient.gender === 'male' ? 'https://via.placeholder.com/50?text=Male' : $scope.patient.gender === 'female' ? 'https://via.placeholder.com/50?text=Female' : 'https://via.placeholder.com/50?text=Avatar';
    };

    // Recording popup management
    $scope.showRecordingPopup = function() {
        $scope.showRecordingPopupFlag = true;
        $scope.isRecording = false;
        $scope.audioBlob = null;
        audioChunks = [];
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.startRecording = function() {
        // Check if the browser supports navigator.mediaDevices and getUserMedia
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert('Recording is not supported in this browser or context. Please use a modern browser and ensure the site is served over HTTPS or localhost.');
            return;
        }

        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                mediaRecorder = new MediaRecorder(stream);
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                analyser = audioContext.createAnalyser();
                source = audioContext.createMediaStreamSource(stream);
                source.connect(analyser);
                analyser.fftSize = 256;
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);

                canvasContext = document.getElementById('waveform').getContext('2d');
                canvasContext.clearRect(0, 0, 400, 100);

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };
                mediaRecorder.onstop = () => {
                    $scope.audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    audioChunks = [];
                    if (source) source.disconnect();
                    if (analyser) analyser.disconnect();
                    if (audioContext) audioContext.close();
                    cancelAnimationFrame(drawFrame);
                    canvasContext.clearRect(0, 0, 400, 100);
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                };
                mediaRecorder.start();

                function draw() {
                    drawFrame = requestAnimationFrame(draw);
                    analyser.getByteFrequencyData(dataArray);
                    canvasContext.fillStyle = 'rgb(200, 200, 200)';
                    canvasContext.fillRect(0, 0, 400, 100);
                    const barWidth = (400 / bufferLength) * 2.5;
                    let x = 0;
                    for (let i = 0; i < bufferLength; i++) {
                        const barHeight = dataArray[i] / 2;
                        canvasContext.fillStyle = `rgb(${barHeight + 100}, 50, 50)`;
                        canvasContext.fillRect(x, 100 - barHeight, barWidth, barHeight);
                        x += barWidth + 1;
                    }
                }

                draw();
                $scope.isRecording = true;
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            })
            .catch(err => {
                console.error('Error accessing microphone:', err);
                alert('Error accessing microphone: ' + err.message + '. Please ensure you have granted microphone permissions and are using a secure context (HTTPS or localhost).');
            });
    };

    $scope.stopRecording = function() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
            $scope.isRecording = false;
            if (source) source.disconnect();
            if (analyser) analyser.disconnect();
            if (audioContext) audioContext.close();
            cancelAnimationFrame(drawFrame);
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }
    };
	
	$scope.generate15DigitNumber = function () {
		const randomNumber = Math.floor(Math.random() * 9e14) + 1e14; // Ensures 15 digits
		return randomNumber.toString();
	};
	
	function fixInvalidJson(jsonStr) {
		  // 1. Replace only property names single quotes with double quotes
		  jsonStr = jsonStr.replace(/'([a-zA-Z0-9_ ]+)'(?=\s*:)/g, '"$1"');

		  // 2. Replace only string values single quotes with double quotes,
		  // but skip apostrophes inside strings by matching only whole string values
		  jsonStr = jsonStr.replace(/:\s*'([^']*?)'/g, (match, p1) => {
			// escape internal double quotes if any
			const escaped = p1.replace(/"/g, '\\"');
			return `: "${escaped}"`;
		  });

		  return jsonStr;
		}

	$scope.uploadFIletoServer = function(mp3Blob){
		debugger
		var generateRandomNumber = $scope.generate15DigitNumber();
		var fileName = generateRandomNumber + '-' +  new Date().toISOString().replace(/[:.]/g, '-')+ '.mp3';
		var formData = new FormData();

		formData.append('file', mp3Blob, fileName);
		formData.append('userId', $scope.userId); // optional if your backend needs it

		$http.post('script/upload.php', formData, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined }
		}).then(function (response) {
			debugger;
			if(response.data.success == true)
			{
				const mp3Url = "https://mycloudfish.com/RequestedFileDir/data/786400/Communication Skills： A Patient-Centered Approach(1).mp3";
				const prompt = `Based on the following patient encounter details, return the following four outputs as strictly formatted JSON objects. Each section must return only a valid JSON object — no additional text, headers, or markdown.
 
Return a JSON object with these fields and Return valid JSON using double quotes only, escape inner quotes properly.:  
{
  "Name": "",
  "Gender": "",
  "Age": "",
  "Weight": "",
  "Height": "",
  "Blood_Pressure": "",
  "Temperature": "",
  "Oxygen_Level": "",
  "Past_Medical_History": "",
  "Allergies": "",
  "Reason_for_Visit": "",
  "subjective": "",
  "objective": "",
  "assessment": "",
  "plan": "",
  "Primary_diagnosis": "",
  "Secondary_diagnosis": "",
  "Differential_diagnoses": [
    { "diagnosis": "", "justification": "" }
  ],
  "Clinical_Rationale": "",
  "Next_Recommended_Actions": [""],
  "Red_Flag_Alerts": [""],
  "urgency_level": "routine",
  "Diagnosis_Codes": [
    { "code": "", "description": "" }
  ],
  "Procedure_Codes": [
    { "code": "", "description": "" }
  ],
  "Prior_Authorization_Package": "",
  "Supporting_Documentation": ""
}

`;
				utilsService.sendMp3ToAI(mp3Url,prompt, "Communication Skills： A Patient-Centered Approach(1).mp3");
				$rootScope.$watch('rawAiResText', function(newVal, oldVal) {
				  if (newVal && typeof newVal === 'string') {
					try {
						debugger;
					  const match = newVal.match(/\{[\s\S]*\}/);
						if (match) {
						  try {
							  // Use JSON5 instead of fixInvalidJson
							  const jsonObj = JSON5.parse(match[0]); // handles single quotes, etc.
							  console.log('Parsed object:', jsonObj);
							  $scope.fillPatientData(jsonObj);
							} catch (err) {
							  console.error('Failed to parse JSON5:', err.message);
							}
						}
					} catch (err) {
					  console.error("Error parsing JSON:", err);
					}
				  }
				});
			}
		}).catch(function (error) {
			console.error('Upload failed:', error);
		});
	}
	$scope.fillPatientData = function(jsonObj){
		if(!jsonObj)
			return;
		debugger
		// Update $scope.patient
		if (jsonObj.Name) $scope.patient.name = jsonObj.Name;
		if (jsonObj.Gender) $scope.patient.gender = jsonObj.Gender;
		if (jsonObj.Age) $scope.patient.age = jsonObj.Age || 'Not specified';
		if (jsonObj.Weight) $scope.patient.weight = jsonObj.Weight || 'Not specified';
		if (jsonObj.Height) $scope.patient.height = jsonObj.Height || 'Not specified';
		if (jsonObj['Blood_Pressure']) $scope.patient.bloodPressure = jsonObj['Blood_Pressure'];
		if (jsonObj.Temperature) $scope.patient.temperature = jsonObj.Temperature;
		if (jsonObj['Oxygen_Level']) $scope.patient.oxygenLevel = jsonObj['Oxygen_Level'];
		if (jsonObj['Past_Medical_History']) $scope.patient.medicalHistory = jsonObj['Past_Medical_History'];
		if (jsonObj.Allergies) $scope.patient.allergies = jsonObj.Allergies;

		// Update $scope.soap
		if (jsonObj.subjective) $scope.soap.subjective = jsonObj.subjective;
		if (jsonObj.objective) $scope.soap.objective = jsonObj.objective;
		if (jsonObj.assessment) $scope.soap.assessment = jsonObj.assessment;
		if (jsonObj.plan) $scope.soap.plan = jsonObj.plan;

		// Update $scope.diagnostic
		if (jsonObj['Primary_diagnosis']) $scope.diagnostic.primaryDiagnosis = jsonObj['Primary_diagnosis'];
		if (jsonObj.Differential_diagnoses) $scope.diagnostic.differentialDiagnosis = JSON.stringify(jsonObj.Differential_diagnoses);
		if (jsonObj['Clinical_Rationale']) $scope.diagnostic.clinicalRationale = jsonObj['Clinical_Rationale'];
		if (jsonObj['Next_Recommended_Actions']) $scope.diagnostic.nextSteps = JSON.stringify(jsonObj['Next_Recommended_Actions']);
		if (jsonObj['Red_Flag_Alerts']) $scope.diagnostic.redFlags = jsonObj['Red_Flag_Alerts'].join(', ');
		if (jsonObj.urgency_level) $scope.diagnostic.urgencyLevel = jsonObj.urgency_level;

		// Update $scope.coding
		if (jsonObj['Diagnosis_Codes']) {
		  $scope.coding.primaryDiagnosisCode = jsonObj['Diagnosis_Codes'][0]?.code || '';
		}
		if (jsonObj['Procedure_Codes']) {
		  $scope.coding.procedureCodes = jsonObj['Procedure_Codes'][0]?.code || '';
		}
		if (jsonObj['Prior_Authorization Package']) {
		  $scope.coding.priorAuthorization = jsonObj['Prior Authorization Package'];
		}
		if (jsonObj.documentation_notes) {
		  $scope.coding.supportingDocumentation = jsonObj.documentation_notes;
		}
		
		$scope.differentialDiagnoses = $scope.parseDifferentialDiagnosis();
		$scope.nextStepsList = $scope.parseNextSteps();

		$scope.$applyAsync(); // apply changes to the view if outside Angular digest cycle
		
		saveToLocalStorage()
		loadData
	}
    $scope.saveRecording = function() {
        if ($scope.audioBlob) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const audioData = event.target.result;
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                audioContext.decodeAudioData(audioData.slice(0), function(buffer) {
                    const mp3Encoder = new lamejs.Mp3Encoder(1, 44100, 128); // 1 channel, 44.1kHz sample rate, 128kbps
                    const samples = buffer.getChannelData(0);
                    const mp3Data = [];
                    const sampleBlockSize = 1152; // Optimal block size for lamejs
                    for (let i = 0; i < samples.length; i += sampleBlockSize) {
                        const sampleChunk = samples.subarray(i, i + sampleBlockSize);
                        const mp3buf = mp3Encoder.encodeBuffer(sampleChunk);
                        if (mp3buf.length > 0) {
                            mp3Data.push(mp3buf);
                        }
                    }
                    const mp3buf = mp3Encoder.flush();
                    if (mp3buf.length > 0) {
                        mp3Data.push(mp3buf);
                    }

                    const mp3Blob = new Blob(mp3Data, { type: 'audio/mpeg' });
					$scope.uploadFIletoServer(mp3Blob);
                    const url = URL.createObjectURL(mp3Blob);
                    const link = document.createElement('a');
                    link.href = url;
					var generateRandomNumber = $scope.generate15DigitNumber();
                    link.download = 'data/'+$scope.userId+'/'+generateRandomNumber+'-' + new Date().toISOString() + '.mp3';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                }, function(err) {
                    console.error('Error decoding audio:', err);
                    alert('Error converting to MP3: ' + err.message);
                });
            };
            reader.readAsArrayBuffer($scope.audioBlob);
        }
		
        $scope.showRecordingPopupFlag = false;
        $scope.audioBlob = null;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.cancelRecording = function() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
        $scope.showRecordingPopupFlag = false;
        $scope.isRecording = false;
        $scope.audioBlob = null;
        audioChunks = [];
        if (source) source.disconnect();
        if (analyser) analyser.disconnect();
        if (audioContext) audioContext.close();
        cancelAnimationFrame(drawFrame);
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Popup management for document actions
    $scope.showPopup = false;
    $scope.popupTitle = '';
    $scope.popupAction = '';
    $scope.showDocumentPopup = function(action) {
        $scope.popupTitle = action === 'save' ? 'Save as Word Document' : action === 'email' ? 'Email Document' : 'Send to EMR';
        $scope.popupAction = action;
        $scope.showPopup = true;
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    $scope.handlePopupAction = function(action) {
        if (action === 'save') {
            $scope.downloadAsWord();
        } else if (action === 'email') {
            alert('Emailing document...');
        } else if (action === 'cancel') {
            $scope.showPopup = false;
        }
        $scope.showPopup = false;
        if (!$scope.$$phase) {
            $scope.$apply(); // Only call $apply if not in a digest cycle
        }
    };

    // Download as PDF function with improved formatting
    $scope.downloadAsPDF = function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const margin = 10;
        const maxWidth = pageWidth - 2 * margin;
        let yPosition = margin;

        const addText = (text, x, y, fontSize, isBold = false) => {
            if (!text) text = 'Not specified'; // Handle null/undefined values
            doc.setFontSize(fontSize);
            doc.setFont(undefined, isBold ? 'bold' : 'normal');
            const splitText = doc.splitTextToSize(text, maxWidth);
            splitText.forEach(line => {
                if (yPosition + fontSize > doc.internal.pageSize.getHeight() - margin) {
                    doc.addPage();
                    yPosition = margin;
                }
                doc.text(line, x, yPosition);
                yPosition += fontSize * 0.5;
            });
            return yPosition;
        };

        yPosition = addText('Medical Report', margin, yPosition, 20, true);
        yPosition += 10;

        yPosition = addText('Patient Information', margin, yPosition, 14, true);
        yPosition += 5;
        const patientFields = [
            `Name: ${$scope.patient.name || 'Not specified'}`,
            `Gender: ${$scope.patient.gender || 'Not specified'}`,
            `Age: ${$scope.patient.age || 'Not specified'}`,
            `Weight: ${$scope.patient.weight || 'Not specified'}`,
            `Height: ${$scope.patient.height || 'Not specified'}`,
            `Blood Pressure: ${$scope.patient.bloodPressure || 'Not specified'}`,
            `Temperature: ${$scope.patient.temperature || 'Not specified'}`,
            `Oxygen Level: ${$scope.patient.oxygenLevel || 'Not specified'}`,
            `Date: ${$scope.patient.date || 'Not specified'}`,
            `Time: ${$scope.patient.time || 'Not specified'}`,
            `Past Medical History: ${$scope.patient.medicalHistory || 'Not specified'}`,
            `Allergies: ${$scope.patient.allergies || 'Not specified'}`,
            `Reason for Visit: ${$scope.patient.reasonForVisit || 'Not specified'}`
        ];
        patientFields.forEach(field => {
            yPosition = addText(field, margin, yPosition, 12);
            yPosition += 2;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('SOAP Notes', margin, yPosition, 14, true);
        yPosition += 5;
        const soapFields = [
            { label: 'Subjective', value: $scope.soap.subjective || 'Not specified' },
            { label: 'Objective', value: $scope.soap.objective || 'Not specified' },
            { label: 'Assessment', value: $scope.soap.assessment || 'Not specified' },
            { label: 'Plan', value: $scope.soap.plan || 'Not specified' }
        ];
        soapFields.forEach(field => {
            yPosition = addText(`${field.label}:`, margin, yPosition, 12, true);
            yPosition = addText(field.value, margin, yPosition, 12);
            yPosition += 5;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Diagnostic', margin, yPosition, 14, true);
        yPosition += 5;
        yPosition = addText('Primary Diagnosis:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.primaryDiagnosis || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Differential Diagnosis:', margin, yPosition, 12, true);
        $scope.differentialDiagnoses.forEach(diff => {
            yPosition = addText(`- ${diff.diagnosis}: ${diff.justification}`, margin + 5, yPosition, 12);
        });
        yPosition += 5;
        yPosition = addText('Clinical Rationale:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.clinicalRationale || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Next Steps:', margin, yPosition, 12, true);
        $scope.nextStepsList.forEach(step => {
            yPosition = addText(`- ${step}`, margin + 5, yPosition, 12);
        });
        yPosition += 5;
        yPosition = addText('Red Flags:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.redFlags || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Urgency Level:', margin, yPosition, 12, true);
        yPosition = addText($scope.diagnostic.urgencyLevel || 'Not specified', margin, yPosition, 12);

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Coding Summary', margin, yPosition, 14, true);
        yPosition += 5;
        const codingFields = [
            `Primary Diagnosis Code: ${$scope.coding.primaryDiagnosisCode || 'Not specified'}`,
            `Secondary Diagnosis Code: ${$scope.coding.secondaryDiagnosisCode || 'Not specified'}`,
            `Procedure Codes: ${$scope.coding.procedureCodes || 'Not specified'}`,
            `Prior Authorization: ${$scope.coding.priorAuthorization || 'Not specified'}`,
            `Supporting Documentation: ${$scope.coding.supportingDocumentation || 'Not specified'}`
        ];
        codingFields.forEach(field => {
            yPosition = addText(field, margin, yPosition, 12);
            yPosition += 2;
        });

        doc.save('medical_report.pdf');
    };

    // Download as Word (simulated)
    $scope.downloadAsWord = function() {
        const content = `
            <html>
            <body>
                <h1>Medical Report</h1>
                <h2>Patient Information</h2>
                <p>Name: ${$scope.patient.name || 'Not specified'}</p>
                <p>Gender: ${$scope.patient.gender || 'Not specified'}</p>
                <p>Age: ${$scope.patient.age || 'Not specified'}</p>
                <p>Weight: ${$scope.patient.weight || 'Not specified'}</p>
                <p>Height: ${$scope.patient.height || 'Not specified'}</p>
                <p>Blood Pressure: ${$scope.patient.bloodPressure || 'Not specified'}</p>
                <p>Temperature: ${$scope.patient.temperature || 'Not specified'}</p>
                <p>Oxygen Level: ${$scope.patient.oxygenLevel || 'Not specified'}</p>
                <p>Date: ${$scope.patient.date || 'Not specified'}</p>
                <p>Time: ${$scope.patient.time || 'Not specified'}</p>
                <p>Past Medical History: ${$scope.patient.medicalHistory || 'Not specified'}</p>
                <p>Allergies: ${$scope.patient.allergies || 'Not specified'}</p>
                <p>Reason for Visit: ${$scope.patient.reasonForVisit || 'Not specified'}</p>
                <h2>SOAP Notes</h2>
                <p>Subjective: ${$scope.soap.subjective || 'Not specified'}</p>
                <p>Objective: ${$scope.soap.objective || 'Not specified'}</p>
                <p>Assessment: ${$scope.soap.assessment || 'Not specified'}</p>
                <p>Plan: ${$scope.soap.plan || 'Not specified'}</p>
                <h2>Diagnostic</h2>
                <p>Primary Diagnosis: ${$scope.diagnostic.primaryDiagnosis || 'Not specified'}</p>
                <p>Differential Diagnosis: ${$scope.differentialDiagnoses.map(diff => `- ${diff.diagnosis}: ${diff.justification}`).join('<br>')}</p>
                <p>Clinical Rationale: ${$scope.diagnostic.clinicalRationale || 'Not specified'}</p>
                <p>Next Steps: ${$scope.nextStepsList.map(step => `- ${step}`).join('<br>')}</p>
                <p>Red Flags: ${$scope.diagnostic.redFlags || 'Not specified'}</p>
                <p>Urgency Level: ${$scope.diagnostic.urgencyLevel || 'Not specified'}</p>
                <h2>Coding Summary</h2>
                <p>Primary Diagnosis Code: ${$scope.coding.primaryDiagnosisCode || 'Not specified'}</p>
                <p>Secondary Diagnosis Code: ${$scope.coding.secondaryDiagnosisCode || 'Not specified'}</p>
                <p>Procedure Codes: ${$scope.coding.procedureCodes || 'Not specified'}</p>
                <p>Prior Authorization: ${$scope.coding.priorAuthorization || 'Not specified'}</p>
                <p>Supporting Documentation: ${$scope.coding.supportingDocumentation || 'Not specified'}</p>
            </body>
            </html>
        `;
        const blob = new Blob([content], { type: 'application/msword' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'medical_report.doc';
        link.click();
    };
}]);
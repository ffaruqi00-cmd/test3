var app = angular.module('authApp', ['ngCookies']);

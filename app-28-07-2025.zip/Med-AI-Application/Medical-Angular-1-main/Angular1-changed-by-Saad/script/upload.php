<?php
$userId = $_POST['userId'];
$uploadDir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'RequestedFileDir/data/'.$userId;

// Create directory if it doesn't exist
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}




if (isset($_FILES['file'])) {
    $targetFile = $uploadDir ."/". basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
        echo json_encode(['success' => true, 'file' => $targetFile]);
    } else {
        echo json_encode(['success' => false, 'error' => $targetFile.'----Failed to move file']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No file received']);
}
?>
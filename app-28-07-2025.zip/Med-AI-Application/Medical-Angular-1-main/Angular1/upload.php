<?php
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handleUpload();
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = isset($_GET['action']) ? $_GET['action'] : 'list';
    if ($action === 'list') {
        handleListFiles();
    } elseif ($action === 'loadFile') {
        handleLoadFile();
    } else {
        echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}

// ================= Upload Handler =================
function handleUpload() {
    $userId = isset($_POST['userId']) ? $_POST['userId'] : 'unknown';
    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'RequestedFileDir' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . $userId;

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $fileName = basename($file['name']);
        $targetFile = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            $response = ['success' => true, 'file' => $fileName];
        } else {
            $response = ['success' => false, 'error' => 'Failed to move file'];
        }
    } else {
        $response = ['success' => false, 'error' => 'No file received'];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}

// ================= List Files =================
function handleListFiles() {
    $userId = isset($_GET['userId']) ? $_GET['userId'] : null;
    if (!$userId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing userId']);
        return;
    }

    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'RequestedFileDir' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . $userId;
    if (!is_dir($uploadDir)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'User directory not found']);
        return;
    }

    $files = array_diff(scandir($uploadDir), ['.', '..']);
    $jsonFiles = [];

    foreach ($files as $file) {
        if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'json') {
            $filePath = $uploadDir . DIRECTORY_SEPARATOR . $file;
            $fileSizeKB = round(filesize($filePath) / 1024, 2);
            $modifiedTime = date("Y-m-d H:i:s", filemtime($filePath));

            $jsonContent = file_get_contents($filePath);
            $jsonData = json_decode($jsonContent, true);

            $name = isset($jsonData['Name']) ? $jsonData['Name'] : '';
            $age = isset($jsonData['Age']) ? $jsonData['Age'] : '';
            $gender = isset($jsonData['Gender']) ? $jsonData['Gender'] : '';

            $jsonFiles[] = [
                'fileName' => $file,
                'sizeKB' => $fileSizeKB,
                'modified' => $modifiedTime,
                'name' => $name,
                'age' => $age,
                'gender' => $gender
            ];
        }
    }

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'files' => $jsonFiles]);
}

// ================= Load Single File =================
function handleLoadFile() {
    $userId = isset($_GET['userId']) ? $_GET['userId'] : null;
    $fileName = isset($_GET['fileName']) ? $_GET['fileName'] : null;

    if (!$userId || !$fileName) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing userId or fileName']);
        return;
    }

    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'RequestedFileDir' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . $userId;
    $filePath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

    if (!file_exists($filePath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'File not found']);
        return;
    }

    $jsonContent = file_get_contents($filePath);
    $jsonData = json_decode($jsonContent, true);

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $jsonData]);
}
?>

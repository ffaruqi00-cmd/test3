angular.module('myApp').controller('MainController', ['$scope', '$window', '$location', '$routeParams', '$http', 'utilsService', function($scope, $window, $location, $routeParams, $http, utilsService) {
    // Mock users data for /users endpoint
    $scope.users = [
        { userId: 7, userName: 'Riley Evans', date: '2025-06-01', time: '15:30' },
        { userId: 8, userName: 'Drew Parker', date: '2025-06-01', time: '10:45' },
        { userId: 9, userName: 'Logan Hayes', date: '2025-06-01', time: '12:00' },
        { userId: 10, userName: 'Quinn Foster', date: '2025-06-01', time: '14:00' }
    ];

    // Mock user data for /userInfo endpoint
    const userData = {
        7: {
            name: 'Riley Evans',
            gender: 'female',
            age: 40,
            weight: '150 lbs',
            height: '5\'7"',
            medicalHistory: 'Migraines',
            allergies: 'None',
            reasonForVisit: 'Frequent headaches',
            bloodPressure: '125/80 mmHg',
            temperature: '98.3°F',
            oxygenLevel: '98%',
            date: '2025-06-01',
            time: '15:30',
            subjective: 'Patient reports frequent headaches, sometimes with aura.',
            objective: 'No neurological deficits noted.',
            assessment: 'Migraine recurrence.',
            plan: 'Adjust migraine medication. Follow-up in 2 weeks.',
            primaryDiagnosis: 'Migraine with aura',
            differentialDiagnoses: [
                { diagnosis: 'Tension headache', justification: 'Frequent headaches' },
                { diagnosis: 'Cluster headache', justification: 'Aura symptoms' }
            ],
            clinicalRationale: 'Headaches with aura align with patient’s migraine history.',
            nextStepsList: ['Adjust medication', 'Monitor frequency'],
            redFlags: 'None noted',
            urgencyLevel: 'moderate',
            primaryDiagnosisCode: 'G43.109',
            secondaryDiagnosisCode: '',
            procedureCodes: '',
            priorAuthorization: '',
            supportingDocumentation: 'Diagnosis code reflects migraine with aura.'
        },
        8: {
            name: 'Drew Parker',
            gender: 'male',
            age: 50,
            weight: '200 lbs',
            height: '6\'1"',
            medicalHistory: 'Heart disease',
            allergies: 'None',
            reasonForVisit: 'Fatigue',
            bloodPressure: '140/90 mmHg',
            temperature: '98.7°F',
            oxygenLevel: '96%',
            date: '2025-06-01',
            time: '10:45',
            subjective: 'Patient reports fatigue and occasional shortness of breath.',
            objective: 'Mild tachycardia noted.',
            assessment: 'Possible heart disease progression.',
            plan: 'Order echocardiogram. Follow-up with cardiologist.',
            primaryDiagnosis: 'Heart disease progression',
            differentialDiagnoses: [
                { diagnosis: 'Anemia', justification: 'Fatigue' },
                { diagnosis: 'Pulmonary issue', justification: 'Shortness of breath' }
            ],
            clinicalRationale: 'Fatigue and tachycardia suggest heart disease progression.',
            nextStepsList: ['Order echocardiogram', 'Cardiology consult'],
            redFlags: 'Tachycardia, history of heart disease',
            urgencyLevel: 'urgent',
            primaryDiagnosisCode: 'I25.9',
            secondaryDiagnosisCode: '',
            procedureCodes: '',
            priorAuthorization: '',
            supportingDocumentation: 'Diagnosis code reflects chronic ischemic heart disease.'
        },
        9: {
            name: 'Logan Hayes',
            gender: 'female',
            age: 35,
            weight: '135 lbs',
            height: '5\'5"',
            medicalHistory: 'Thyroid issues',
            allergies: 'Shellfish',
            reasonForVisit: 'Weight gain',
            bloodPressure: '120/78 mmHg',
            temperature: '98.4°F',
            oxygenLevel: '99%',
            date: '2025-06-01',
            time: '12:00',
            subjective: 'Patient reports unexplained weight gain over 2 months.',
            objective: 'Slightly enlarged thyroid noted.',
            assessment: 'Possible hypothyroidism.',
            plan: 'Order thyroid function tests. Follow-up in 2 weeks.',
            primaryDiagnosis: 'Possible hypothyroidism',
            differentialDiagnoses: [
                { diagnosis: 'Obesity', justification: 'Weight gain' },
                { diagnosis: 'Cushing\'s syndrome', justification: 'Unexplained weight gain' }
            ],
            clinicalRationale: 'Weight gain and thyroid enlargement suggest hypothyroidism.',
            nextStepsList: ['Order thyroid tests', 'Monitor weight'],
            redFlags: 'None noted',
            urgencyLevel: 'routine',
            primaryDiagnosisCode: 'E03.9',
            secondaryDiagnosisCode: '',
            procedureCodes: '',
            priorAuthorization: '',
            supportingDocumentation: 'Diagnosis code reflects unspecified hypothyroidism.'
        },
        10: {
            name: 'Quinn Foster',
            gender: 'male',
            age: 48,
            weight: '185 lbs',
            height: '5\'9"',
            medicalHistory: 'Back pain',
            allergies: 'None',
            reasonForVisit: 'Severe back pain',
            bloodPressure: '130/85 mmHg',
            temperature: '98.6°F',
            oxygenLevel: '98%',
            date: '2025-06-01',
            time: '14:00',
            subjective: 'Patient reports severe back pain after lifting heavy objects.',
            objective: 'Limited mobility, tenderness in lower back.',
            assessment: 'Acute back strain.',
            plan: 'Prescribe pain relief and physical therapy. Follow-up in 1 week.',
            primaryDiagnosis: 'Acute back strain',
            differentialDiagnoses: [
                { diagnosis: 'Herniated disc', justification: 'Severe pain' },
                { diagnosis: 'Muscle spasm', justification: 'Tenderness' }
            ],
            clinicalRationale: 'Pain and limited mobility suggest acute back strain.',
            nextStepsList: ['Prescribe pain relief', 'Refer to physical therapy'],
            redFlags: 'None noted',
            urgencyLevel: 'moderate',
            primaryDiagnosisCode: 'M79.1',
            secondaryDiagnosisCode: '',
            procedureCodes: '',
            priorAuthorization: '',
            supportingDocumentation: 'Diagnosis code reflects myofascial pain syndrome.'
        }
    };

    // Initialize variables
    $scope.showRecordingPopupFlag = false;
    $scope.isRecording = false;
    $scope.audioBlob = null;
    $scope.isLoading = false;
    $scope.isDropdownOpen = false;
    $scope.showPopup = false;
    $scope.popupTitle = '';
    $scope.popupAction = '';
    $scope.isEditing = {};
    $scope.uiFields = {};
    $scope.searchTerm = '';
    $scope.showInfoDialog = false;
    $scope.infoDialogMessage = '';
    $scope.isUploading = false;
    let mediaRecorder = null;
    let audioChunks = [];
    let audioContext = null;
    let analyser = null;
    let canvasContext = null;
    let source = null;
    let drawFrame = null;

    // Load user data and patient list
    const loadUserData = () => {
        const userId = $routeParams.userId;
        if (userId) {
            const savedData = $window.localStorage.getItem('medicalData_' + userId);
            if (savedData) {
                $scope.uiFields = JSON.parse(savedData);
                // Convert age to number if it exists
                if ($scope.uiFields.age) {
                    $scope.uiFields.age = parseInt($scope.uiFields.age, 10) || '';
                }
            } else {
                const userInfo = userData[userId];
                if (userInfo) {
                    $scope.uiFields = angular.copy(userInfo);
                    // Convert age to number
                    $scope.uiFields.age = parseInt($scope.uiFields.age, 10) || '';
                }
            }
        } else {
            $scope.uiFields = {};
        }
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    const loadPatientList = () => {
        const savedPatients = $window.localStorage.getItem('patientList');
        if (savedPatients) {
            const parsedPatients = JSON.parse(savedPatients);
            // Merge with existing users, avoiding duplicates by userId
            $scope.users = [...$scope.users, ...parsedPatients].reduce((unique, item) => {
                if (!unique.find(u => u.userId === item.userId)) {
                    unique.push(item);
                }
                return unique;
            }, []);
        }
    };
    loadUserData();
    loadPatientList();

    // Navigation functions
    $scope.viewUser = function(userId) {
        $location.path('/userInfo/' + userId);
    };

    $scope.goToUsers = function() {
        loadPatientList(); // Reload patient list before navigating
        $location.path('/users');
    };

    // Dropdown and popup functions
    $scope.toggleDropdown = function() {
        $scope.isDropdownOpen = !$scope.isDropdownOpen;
    };

    $scope.showDocumentPopup = function(action) {
        $scope.showPopup = true;
        $scope.popupAction = action;
        $scope.popupTitle = action === 'save' ? 'Save Document' : action === 'email' ? 'Email Document' : 'Send to EMR';
    };

    $scope.handlePopupAction = function(action) {
        if (action === 'cancel') {
            $scope.showPopup = false;
        } else if (action === 'save') {
            $scope.downloadAsWord();
        } else if (action === 'email') {
            alert('Emailing document...');
        }
        $scope.showPopup = false;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Edit and save functions
    $scope.toggleEdit = function(section) {
        $scope.isEditing[section] = !$scope.isEditing[section];
    };

    $scope.saveEdit = function(section) {
        $scope.isEditing[section] = false;
        saveToLocalStorage();
    };

    $scope.saveAllPatientInfo = function() {
        $scope.isEditing['patient'] = false;
        saveToLocalStorage();
    };

    $scope.saveMedicalInfo = function() {
        $scope.isEditing['medicalInfo'] = false;
        saveToLocalStorage();
    };

    // Save to localStorage
    const saveToLocalStorage = () => {
        const userId = $routeParams.userId;
        if (userId) {
            $window.localStorage.setItem('medicalData_' + userId, JSON.stringify($scope.uiFields));
        }
    };

    // Handle outside click for dropdown and auto-save
    $scope.handleOutsideClick = function($event) {
        const target = $event.target;
        const isInsideInput = target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA';
        const isInsideEditable = target.closest('.info-field, .history-field, .card-content');
        const isInsideDropdown = target.closest('.dropdown');
        const isInsidePopup = target.closest('.popup');

        let needsSave = false;
        if (!isInsideInput && !isInsideEditable && !isInsidePopup) {
            Object.keys($scope.isEditing).forEach(key => {
                if ($scope.isEditing[key]) {
                    $scope.isEditing[key] = false;
                    needsSave = true;
                }
            });
            if (needsSave) {
                saveToLocalStorage();
            }
        }

        if (!isInsideDropdown && $scope.isDropdownOpen) {
            $scope.isDropdownOpen = false;
        }

        if ((needsSave || (!isInsideDropdown && $scope.isDropdownOpen)) && !$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Audio recording functions
    $scope.generate15DigitNumber = function() {
        const randomNumber = Math.floor(Math.random() * 9e14) + 1e14;
        return randomNumber.toString();
    };

    $scope.showRecordingPopup = function() {
        $scope.showRecordingPopupFlag = true;
        $scope.isRecording = false;
        $scope.audioBlob = null;
        $scope.isLoading = false;
        $scope.isUploading = false;
        audioChunks = [];
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.startRecording = function() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert('Recording is not supported in this browser or context. Please use a modern browser and ensure the site is served over HTTPS or localhost.');
            return;
        }

        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                mediaRecorder = new MediaRecorder(stream);
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
                analyser = audioContext.createAnalyser();
                source = audioContext.createMediaStreamSource(stream);
                source.connect(analyser);
                analyser.fftSize = 256;
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);

                canvasContext = document.getElementById('waveform').getContext('2d');
                canvasContext.clearRect(0, 0, 530, 100);

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };
                mediaRecorder.onstop = () => {
                    if (audioChunks.length > 0) {
                        $scope.audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                        audioChunks = [];
                    }
                    if (source) source.disconnect();
                    if (analyser) analyser.disconnect();
                    if (audioContext && audioContext.state !== 'closed') {
                        audioContext.close().then(() => {
                            audioContext = null;
                        });
                    }
                    cancelAnimationFrame(drawFrame);
                    canvasContext.clearRect(0, 0, 530, 100);
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                };
                mediaRecorder.start();

                function draw() {
                    drawFrame = requestAnimationFrame(draw);
                    analyser.getByteFrequencyData(dataArray);
                    canvasContext.fillStyle = 'rgb(200, 200, 200)';
                    canvasContext.fillRect(0, 0, 530, 100);
                    const barWidth = (530 / bufferLength) * 2.5;
                    let x = 0;
                    for (let i = 0; i < bufferLength; i++) {
                        const barHeight = dataArray[i] / 2;
                        canvasContext.fillStyle = `rgb(${barHeight + 100}, 50, 50)`;
                        canvasContext.fillRect(x, 100 - barHeight, barWidth, barHeight);
                        x += barWidth + 1;
                    }
                }

                draw();
                $scope.isRecording = true;
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            })
            .catch(err => {
                alert('Error accessing microphone: ' + err.message + '. Please ensure you have granted microphone permissions and are using a secure context (HTTPS or localhost).');
            });
    };

    $scope.stopRecording = function() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
            $scope.isRecording = false;
            // Ensure audioBlob is set even if onstop fails
            if (audioChunks.length > 0) {
                $scope.audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                audioChunks = [];
            }
            if (source) source.disconnect();
            if (analyser) analyser.disconnect();
            if (audioContext && audioContext.state !== 'closed') {
                audioContext.close().then(() => {
                    audioContext = null;
                });
            }
            cancelAnimationFrame(drawFrame);
            canvasContext.clearRect(0, 0, 530, 100);
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }
    };

    $scope.uploadAudio = function() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'audio/*';
        input.onchange = function(e) {
            const file = e.target.files[0];
            if (file) {
                $scope.audioBlob = file;
                $scope.isUploading = true;
                $scope.isLoading = true;
                $scope.showRecordingPopupFlag = false;
                $scope.showInfoDialog = true;
                $scope.infoDialogMessage = 'Uploading audio file…';
                if (!$scope.$$phase) {
                    $scope.$apply();
                }

                const reader = new FileReader();
                reader.onload = function(event) {
                    const audioData = event.target.result;
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    audioContext.decodeAudioData(audioData.slice(0), function(buffer) {
                        const mp3Encoder = new lamejs.Mp3Encoder(1, buffer.sampleRate || 44100, 128);
                        const samples = buffer.getChannelData(0);

                        let maxSample = 0;
                        for (let i = 0; i < samples.length; i++) {
                            const absSample = Math.abs(samples[i]);
                            if (absSample > maxSample) {
                                maxSample = absSample;
                            }
                        }
                        if (maxSample > 0) {
                            const scale = 0.99 / maxSample;
                            for (let i = 0; i < samples.length; i++) {
                                samples[i] *= scale;
                            }
                        }

                        const intSamples = new Int16Array(samples.length);
                        for (let i = 0; i < samples.length; i++) {
                            intSamples[i] = samples[i] * 32767;
                        }

                        const mp3Data = [];
                        const sampleBlockSize = 1152;
                        for (let i = 0; i < intSamples.length; i += sampleBlockSize) {
                            const sampleChunk = intSamples.subarray(i, i + sampleBlockSize);
                            const mp3buf = mp3Encoder.encodeBuffer(sampleChunk);
                            if (mp3buf.length > 0) {
                                mp3Data.push(mp3buf);
                            }
                        }
                        const mp3buf = mp3Encoder.flush();
                        if (mp3buf.length > 0) {
                            mp3Data.push(mp3buf);
                        }

                        const mp3Blob = new Blob(mp3Data, { type: 'audio/mpeg' });
                        $scope.uploadFileToServer(mp3Blob);
                    }, function(err) {
                        alert('Error converting uploaded audio to MP3: ' + err.message);
                        $scope.isLoading = false;
                        $scope.isUploading = false;
                        $scope.showInfoDialog = false;
                        loadUserData();
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                    });
                };
                reader.onerror = function(err) {
                    alert('Error reading uploaded audio file: ' + err.message);
                    $scope.isLoading = false;
                    $scope.isUploading = false;
                    $scope.showInfoDialog = false;
                    loadUserData();
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                };
                reader.readAsArrayBuffer(file);
            }
        };
        input.click();
    };

    $scope.uploadFileToServer = function(mp3Blob) {
        const userId = $routeParams.userId || 'unknown';
        const generateRandomNumber = $scope.generate15DigitNumber();
        const fileName = `${generateRandomNumber}-${new Date().toISOString().replace(/[:.]/g, '-')}.mp3`;
        const formData = new FormData();

        formData.append('file', mp3Blob, fileName);
        formData.append('userId', userId);

        $scope.isLoading = true;
        $scope.showInfoDialog = true;
        $scope.infoDialogMessage = 'Uploading audio file…';
        if (!$scope.$$phase) {
            $scope.$apply();
        }

        $http.post('https://myveekrypt.com/app/Med-Ai-Application/Medical-Angular-1-main/Angular1/upload.php', formData, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        }).then(function(response) {
            if (response.data.success) {
                alert('Recording saved successfully to recordings folder as ' + fileName);

                const prompt = `Based on the following patient encounter details, return the following four outputs as strictly formatted JSON objects. Each section must return only a valid JSON object — no additional text, headers, or markdown. No PDF please

Return a JSON object with these fields:
{
  "Name": "",
  "Gender": "",
  "Age": "",
  "Weight": "",
  "Height": "",
  "Blood_Pressure": "",
  "Temperature": "",
  "Oxygen_Level": "",
  "Past_Medical_History": "",
  "Allergies": "",
  "Reason_for_Visit": "",
  "subjective": "",
  "objective": "",
  "assessment": "",
  "plan": "",
  "Primary_diagnosis": "",
  "Differential_diagnoses": [
    { "diagnosis": "", "justification": "" }
  ],
  "Clinical_Rationale": "",
  "Next_Recommended_Actions": [""],
  "Red_Flag_Alerts": [""],
  "urgency_level": "routine",
  "Diagnosis_Codes": [
    { "code": "", "description": "" }
  ],
  "Procedure_Codes": [
    { "code": "", "description": "" }
  ],
  "Prior Authorization Package": "",
  "Supporting_Documentation": ""
}`;

                $scope.infoDialogMessage = 'Processing audio with AI…';
                if (!$scope.$$phase) {
                    $scope.$apply();
                }

                utilsService.getResponseFromAIApi(mp3Blob, fileName, 'audio/mpeg', prompt)
                    .then(function(apiResponse) {
                        console.log('API Response:', apiResponse.data); // Debug log
                        if (apiResponse.data && apiResponse.data.status === 'success' && apiResponse.data.response) {
                            const jsonFileName = fileName.replace('.mp3', '.json');
                            const jsonBlob = new Blob([JSON.stringify(apiResponse.data.response, null, 2)], { type: 'application/json' });
                            const jsonFormData = new FormData();
                            jsonFormData.append('file', jsonBlob, jsonFileName);
                            jsonFormData.append('userId', userId);
                            $http.post('https://myveekrypt.com/app/Med-Ai-Application/Medical-Angular-1-main/Angular1/upload.php', jsonFormData, {
                                transformRequest: angular.identity,
                                headers: { 'Content-Type': undefined }
                            }).then(function(jsonResponse) {
                                if (jsonResponse.data.success) {
                                    alert('JSON response saved successfully to recordings folder as ' + jsonFileName);
                                }
                            }).catch(function(error) {
                                alert('Error saving JSON response: ' + error.message);
                            });

                            const apiData = apiResponse.data.response;
                            console.log('API Data to Populate:', apiData); // Debug log
                            // Update uiFields with API data
                            $scope.uiFields = {
                                name: apiData.Name || $scope.uiFields.name || '',
                                gender: apiData.Gender || $scope.uiFields.gender || '',
                                age: parseInt(apiData.Age, 10) || $scope.uiFields.age || '',
                                weight: apiData.Weight || $scope.uiFields.weight || '',
                                height: apiData.Height || $scope.uiFields.height || '',
                                bloodPressure: apiData.Blood_Pressure || $scope.uiFields.bloodPressure || '',
                                temperature: apiData.Temperature || $scope.uiFields.temperature || '',
                                oxygenLevel: apiData.Oxygen_Level || $scope.uiFields.oxygenLevel || '',
                                medicalHistory: apiData.Past_Medical_History || $scope.uiFields.medicalHistory || '',
                                allergies: apiData.Allergies || $scope.uiFields.allergies || '',
                                reasonForVisit: apiData.Reason_for_Visit || $scope.uiFields.reasonForVisit || '',
                                subjective: apiData.subjective || $scope.uiFields.subjective || '',
                                objective: apiData.objective || $scope.uiFields.objective || '',
                                assessment: apiData.assessment || $scope.uiFields.assessment || '',
                                plan: apiData.plan || $scope.uiFields.plan || '',
                                primaryDiagnosis: apiData.Primary_diagnosis || $scope.uiFields.primaryDiagnosis || '',
                                differentialDiagnoses: apiData.Differential_diagnoses || $scope.uiFields.differentialDiagnoses || [],
                                clinicalRationale: apiData.Clinical_Rationale || $scope.uiFields.clinicalRationale || '',
                                nextStepsList: apiData.Next_Recommended_Actions || $scope.uiFields.nextStepsList || [],
                                redFlags: apiData.Red_Flag_Alerts && apiData.Red_Flag_Alerts.length ? apiData.Red_Flag_Alerts.join(', ') : $scope.uiFields.redFlags || '',
                                urgencyLevel: apiData.urgency_level || $scope.uiFields.urgencyLevel || 'routine',
                                primaryDiagnosisCode: apiData.Diagnosis_Codes && apiData.Diagnosis_Codes[0] ? apiData.Diagnosis_Codes[0].code : $scope.uiFields.primaryDiagnosisCode || '',
                                secondaryDiagnosisCode: apiData.Diagnosis_Codes && apiData.Diagnosis_Codes[1] ? apiData.Diagnosis_Codes[1].code : $scope.uiFields.secondaryDiagnosisCode || '',
                                procedureCodes: apiData.Procedure_Codes && apiData.Procedure_Codes.length ? apiData.Procedure_Codes.map(code => `${code.code}: ${code.description}`).join(', ') : $scope.uiFields.procedureCodes || '',
                                priorAuthorization: apiData['Prior Authorization Package'] || $scope.uiFields.priorAuthorization || '',
                                supportingDocumentation: apiData.Supporting_Documentation || $scope.uiFields.supportingDocumentation || ''
                            };
                            console.log('Updated uiFields:', $scope.uiFields); // Debug log
                            saveToLocalStorage();

                            // Save new patient entry to patientList
                            const newUserId = Math.max(...Object.keys(userData).map(Number), ...$scope.users.map(u => u.userId)) + 1;
                            const newPatient = {
                                userId: newUserId,
                                userName: apiData.Name || 'Unknown Patient',
                                date: new Date().toISOString().split('T')[0], // Current date
                                time: new Date().toTimeString().split(' ')[0].slice(0, 5) // Current time (HH:MM)
                            };
                            const savedPatients = $window.localStorage.getItem('patientList');
                            const patientList = savedPatients ? JSON.parse(savedPatients) : [];
                            patientList.push(newPatient);
                            $window.localStorage.setItem('patientList', JSON.stringify(patientList));

                            userData[newUserId] = $scope.uiFields; // Add to userData for future reference
                            alert('Audio processed successfully by API! New patient added.');
                        } else {
                            alert('Failed to process API response: ' + (apiResponse.data.error || 'Unknown error'));
                            loadUserData();
                        }
                    }).catch(function(error) {
                        alert('Error uploading recording to API: ' + error.message);
                        loadUserData();
                    }).finally(function() {
                        $scope.isLoading = false;
                        $scope.isUploading = false;
                        $scope.showInfoDialog = false;
                        if (!$scope.$$phase) {
                            $scope.$apply();
                        }
                    });
            } else {
                alert('Error saving recording: ' + response.data.error);
                loadUserData();
            }
        }).catch(function(error) {
            alert('Error uploading recording to server: ' + error.message);
            loadUserData();
        }).finally(function() {
            $scope.isLoading = false;
            $scope.isUploading = false;
            $scope.showInfoDialog = false;
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        });
    };

    $scope.saveRecording = function() {
        if ($scope.audioBlob) {
            $scope.isUploading = true;
            $scope.isLoading = true;
            $scope.showRecordingPopupFlag = false;
            $scope.showInfoDialog = true;
            $scope.infoDialogMessage = 'Uploading audio file…';
            if (!$scope.$$phase) {
                $scope.$apply();
            }

            const reader = new FileReader();
            reader.onload = function(event) {
                const audioData = event.target.result;
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                audioContext.decodeAudioData(audioData.slice(0), function(buffer) {
                    const mp3Encoder = new lamejs.Mp3Encoder(1, buffer.sampleRate || 44100, 128);
                    const samples = buffer.getChannelData(0);

                    let maxSample = 0;
                    for (let i = 0; i < samples.length; i++) {
                        const absSample = Math.abs(samples[i]);
                        if (absSample > maxSample) {
                            maxSample = absSample;
                        }
                    }
                    if (maxSample > 0) {
                        const scale = 0.99 / maxSample;
                        for (let i = 0; i < samples.length; i++) {
                            samples[i] *= scale;
                        }
                    }

                    const intSamples = new Int16Array(samples.length);
                    for (let i = 0; i < samples.length; i++) {
                        intSamples[i] = samples[i] * 32767;
                    }

                    const mp3Data = [];
                    const sampleBlockSize = 1152;
                    for (let i = 0; i < intSamples.length; i += sampleBlockSize) {
                        const sampleChunk = intSamples.subarray(i, i + sampleBlockSize);
                        const mp3buf = mp3Encoder.encodeBuffer(sampleChunk);
                        if (mp3buf.length > 0) {
                            mp3Data.push(mp3buf);
                        }
                    }
                    const mp3buf = mp3Encoder.flush();
                    if (mp3buf.length > 0) {
                        mp3Data.push(mp3buf);
                    }

                    const mp3Blob = new Blob(mp3Data, { type: 'audio/mpeg' });
                    $scope.uploadFileToServer(mp3Blob);
                }, function(err) {
                    alert('Error converting to MP3: ' + err.message);
                    $scope.isLoading = false;
                    $scope.isUploading = false;
                    $scope.showInfoDialog = false;
                    loadUserData();
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                });
            };
            reader.onerror = function(err) {
                alert('Error reading audioBlob: ' + err.message);
                $scope.isLoading = false;
                $scope.isUploading = false;
                $scope.showInfoDialog = false;
                loadUserData();
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            };
            reader.readAsArrayBuffer($scope.audioBlob);
        } else {
            alert('No recording to save. Please record audio first.');
            $scope.showRecordingPopupFlag = false;
            $scope.isLoading = false;
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }

        $scope.audioBlob = null;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.cancelRecording = function() {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
        $scope.showRecordingPopupFlag = false;
        $scope.isRecording = false;
        $scope.audioBlob = null;
        $scope.isLoading = false;
        $scope.isUploading = false;
        audioChunks = [];
        if (source) source.disconnect();
        if (analyser) analyser.disconnect();
        if (audioContext && audioContext.state !== 'closed') {
            audioContext.close().then(() => {
                audioContext = null;
            });
        }
        cancelAnimationFrame(drawFrame);
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    // Download as PDF function
    $scope.downloadAsPDF = function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const margin = 10;
        const maxWidth = pageWidth - 2 * margin;
        let yPosition = margin;

        const addText = (text, x, y, fontSize, isBold = false) => {
            if (!text) text = 'Not specified';
            doc.setFontSize(fontSize);
            doc.setFont(undefined, isBold ? 'bold' : 'normal');
            const splitText = doc.splitTextToSize(text, maxWidth);
            splitText.forEach(line => {
                if (yPosition + fontSize > doc.internal.pageSize.getHeight() - margin) {
                    doc.addPage();
                    yPosition = margin;
                }
                doc.text(line, x, yPosition);
                yPosition += fontSize * 0.5;
            });
            return yPosition;
        };

        yPosition = addText('Medical Report', margin, yPosition, 20, true);
        yPosition += 10;

        yPosition = addText('Patient Information', margin, yPosition, 14, true);
        yPosition += 5;
        const patientFields = [
            `Name: ${$scope.uiFields.name || 'Not specified'}`,
            `Gender: ${$scope.uiFields.gender || 'Not specified'}`,
            `Age: ${$scope.uiFields.age || 'Not specified'}`,
            `Weight: ${$scope.uiFields.weight || 'Not specified'}`,
            `Height: ${$scope.uiFields.height || 'Not specified'}`,
            `Blood Pressure: ${$scope.uiFields.bloodPressure || 'Not specified'}`,
            `Temperature: ${$scope.uiFields.temperature || 'Not specified'}`,
            `Oxygen Level: ${$scope.uiFields.oxygenLevel || 'Not specified'}`,
            `Date: ${$scope.uiFields.date || 'Not specified'}`,
            `Time: ${$scope.uiFields.time || 'Not specified'}`,
            `Past Medical History: ${$scope.uiFields.medicalHistory || 'Not specified'}`,
            `Allergies: ${$scope.uiFields.allergies || 'Not specified'}`,
            `Reason for Visit: ${$scope.uiFields.reasonForVisit || 'Not specified'}`
        ];
        patientFields.forEach(field => {
            yPosition = addText(field, margin, yPosition, 12);
            yPosition += 2;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('SOAP Notes', margin, yPosition, 14, true);
        yPosition += 5;
        const soapFields = [
            { label: 'Subjective', value: $scope.uiFields.subjective || 'Not specified' },
            { label: 'Objective', value: $scope.uiFields.objective || 'Not specified' },
            { label: 'Assessment', value: $scope.uiFields.assessment || 'Not specified' },
            { label: 'Plan', value: $scope.uiFields.plan || 'Not specified' }
        ];
        soapFields.forEach(field => {
            yPosition = addText(`${field.label}:`, margin, yPosition, 12, true);
            yPosition = addText(field.value, margin, yPosition, 12);
            yPosition += 5;
        });

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Diagnostic', margin, yPosition, 14, true);
        yPosition += 5;
        yPosition = addText('Primary Diagnosis:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.primaryDiagnosis || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Differential Diagnosis:', margin, yPosition, 12, true);
        if ($scope.uiFields.differentialDiagnoses && $scope.uiFields.differentialDiagnoses.length) {
            $scope.uiFields.differentialDiagnoses.forEach(diff => {
                yPosition = addText(`- ${diff.diagnosis}: ${diff.justification}`, margin + 5, yPosition, 12);
            });
        } else {
            yPosition = addText('No differential diagnoses specified', margin + 5, yPosition, 12);
        }
        yPosition += 5;
        yPosition = addText('Clinical Rationale:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.clinicalRationale || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Next Steps:', margin, yPosition, 12, true);
        if ($scope.uiFields.nextStepsList && $scope.uiFields.nextStepsList.length) {
            $scope.uiFields.nextStepsList.forEach(step => {
                yPosition = addText(`- ${step}`, margin + 5, yPosition, 12);
            });
        } else {
            yPosition = addText('No next steps specified', margin + 5, yPosition, 12);
        }
        yPosition += 5;
        yPosition = addText('Red Flags:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.redFlags || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Urgency Level:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.urgencyLevel || 'Not specified', margin, yPosition, 12);

        doc.addPage();
        yPosition = margin;
        yPosition = addText('Coding Summary', margin, yPosition, 14, true);
        yPosition += 5;
        yPosition = addText('Diagnosis Codes:', margin, yPosition, 12, true);
        if ($scope.uiFields.primaryDiagnosisCode || $scope.uiFields.secondaryDiagnosisCode) {
            if ($scope.uiFields.primaryDiagnosisCode) {
                yPosition = addText(`- ${$scope.uiFields.primaryDiagnosisCode}`, margin + 5, yPosition, 12);
            }
            if ($scope.uiFields.secondaryDiagnosisCode) {
                yPosition = addText(`- ${$scope.uiFields.secondaryDiagnosisCode}`, margin + 5, yPosition, 12);
            }
        } else {
            yPosition = addText('No diagnosis codes specified', margin + 5, yPosition, 12);
        }
        yPosition += 5;
        yPosition = addText('Procedure Codes:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.procedureCodes || 'Not specified', margin + 5, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Prior Authorization:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.priorAuthorization || 'Not specified', margin, yPosition, 12);
        yPosition += 5;
        yPosition = addText('Supporting Documentation:', margin, yPosition, 12, true);
        yPosition = addText($scope.uiFields.supportingDocumentation || 'Not specified', margin, yPosition, 12);

        doc.save('medical_report.pdf');
    };

    // Download as Word (simulated)
    $scope.downloadAsWord = function() {
        const content = `
            <html>
            <body>
                <h1>Medical Report</h1>
                <h2>Patient Information</h2>
                <p>Name: ${$scope.uiFields.name || 'Not specified'}</p>
                <p>Gender: ${$scope.uiFields.gender || 'Not specified'}</p>
                <p>Age: ${$scope.uiFields.age || 'Not specified'}</p>
                <p>Weight: ${$scope.uiFields.weight || 'Not specified'}</p>
                <p>Height: ${$scope.uiFields.height || 'Not specified'}</p>
                <p>Blood Pressure: ${$scope.uiFields.bloodPressure || 'Not specified'}</p>
                <p>Temperature: ${$scope.uiFields.temperature || 'Not specified'}</p>
                <p>Oxygen Level: ${$scope.uiFields.oxygenLevel || 'Not specified'}</p>
                <p>Date: ${$scope.uiFields.date || 'Not specified'}</p>
                <p>Time: ${$scope.uiFields.time || 'Not specified'}</p>
                <p>Past Medical History: ${$scope.uiFields.medicalHistory || 'Not specified'}</p>
                <p>Allergies: ${$scope.uiFields.allergies || 'Not specified'}</p>
                <p>Reason for Visit: ${$scope.uiFields.reasonForVisit || 'Not specified'}</p>
                <h2>SOAP Notes</h2>
                <p>Subjective: ${$scope.uiFields.subjective || 'Not specified'}</p>
                <p>Objective: ${$scope.uiFields.objective || 'Not specified'}</p>
                <p>Assessment: ${$scope.uiFields.assessment || 'Not specified'}</p>
                <p>Plan: ${$scope.uiFields.plan || 'Not specified'}</p>
                <h2>Diagnostic</h2>
                <p>Primary Diagnosis: ${$scope.uiFields.primaryDiagnosis || 'Not specified'}</p>
                <p>Differential Diagnosis: ${$scope.uiFields.differentialDiagnoses && $scope.uiFields.differentialDiagnoses.length ? $scope.uiFields.differentialDiagnoses.map(diff => `- ${diff.diagnosis}: ${diff.justification}`).join('<br>') : 'No differential diagnoses specified'}</p>
                <p>Clinical Rationale: ${$scope.uiFields.clinicalRationale || 'Not specified'}</p>
                <p>Next Steps: ${$scope.uiFields.nextStepsList && $scope.uiFields.nextStepsList.length ? $scope.uiFields.nextStepsList.map(step => `- ${step}`).join('<br>') : 'No next steps specified'}</p>
                <p>Red Flags: ${$scope.uiFields.redFlags || 'Not specified'}</p>
                <p>Urgency Level: ${$scope.uiFields.urgencyLevel || 'Not specified'}</p>
                <h2>Coding Summary</h2>
                <p>Diagnosis Codes: ${$scope.uiFields.primaryDiagnosisCode || $scope.uiFields.secondaryDiagnosisCode ? `${$scope.uiFields.primaryDiagnosisCode || ''}, ${$scope.uiFields.secondaryDiagnosisCode || ''}` : 'Not specified'}</p>
                <p>Procedure Codes: ${$scope.uiFields.procedureCodes || 'Not specified'}</p>
                <p>Prior Authorization: ${$scope.uiFields.priorAuthorization || 'Not specified'}</p>
                <p>Supporting Documentation: ${$scope.uiFields.supportingDocumentation || 'Not specified'}</p>
            </body>
            </html>
        `;
        const blob = new Blob([content], { type: 'application/msword' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'medical_report.doc';
        link.click();
    };
}]);
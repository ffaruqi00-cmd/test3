var app = angular.module('myApp', ['ngRoute']);

app.factory('utilsService', ['$http', '$rootScope', function($http, $rootScope) {
    return {
        getResponseFromAIApi: function(file, fileName, mimeType, prompt) {
            $rootScope.isProcessing = true;

            const formData = new FormData();
            formData.append('file', file, fileName);
            formData.append('prompt', prompt);
            formData.append('model_name', 'gpt-4o');

            return $http.post('https://ai-api.mylightening.com/v7/unified-processing', formData, {
                transformRequest: angular.identity,
                headers: { 
                    'Content-Type': undefined,
                    'Authorization': 'someRandom101SecretKey4AIWork' // Replace with your actual API key
                }
            }).finally(function() {
                $rootScope.isProcessing = false;
                if (!$rootScope.$$phase) {
                    $rootScope.$apply();
                }
            });
        }
    };
}]);

app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true);
    $routeProvider
        .when('/users', {
            template: `
                <h1 class="project-title">Patient Visit List</h1>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div></div>
                    <div class="search-container">
                        <input type="text" ng-model="searchTerm" placeholder="Search patients..." class="info-input" style="width: 100%; max-width: 300px; margin-bottom: 20px;">
                    </div>
                </div>
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>Patient Name</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="user in users | filter:searchTerm">
                            <td>{{user.userName}}</td>
                            <td>{{user.date || 'Not specified'}}</td>
                            <td>{{user.time || 'Not specified'}}</td>
                            <td>
                                <button class="action-btn view-details-btn" ng-click="viewUser(user.userId)">View Visit Details</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            `,
            controller: 'MainController'
        })
        .when('/userInfo/:userId', {
            template: `
                <button class="back-to-users-btn" ng-click="goToUsers()">Back to Patient Visit List</button>
                <div ng-controller="MainController">
                    <!-- Toaster Message -->
                    <div class="toaster" ng-show="showToaster" style="position: fixed; top: 10px; right: 10px; background-color: #333; color: white; padding: 10px; border-radius: 5px; z-index: 1000;">
                        {{toasterMessage}}
                    </div>

                    <!-- Header Section -->
                    <div class="header-section">
                        <h1 class="project-title">Medical Assistant - VEEKRYPT</h1>
                        <div class="action-buttons">
                            <button class="action-btn record-btn" ng-click="showRecordingPopup()">Record</button>
                            <button class="action-btn video-btn">Video Call</button>
                            <div class="dropdown">
                                <button class="action-btn actions-btn" ng-click="toggleDropdown()">Actions <span class="dropdown-icon">▼</span></button>
                                <div class="dropdown-content" ng-show="isDropdownOpen">
                                    <button class="action-btn" ng-click="downloadAsPDF()">Save as PDF</button>
                                    <button class="action-btn" ng-click="showDocumentPopup('save')">Save as Word Document</button>
                                    <button class="action-btn" ng-click="showDocumentPopup('email')">Email to Me</button>
                                    <button class="action-btn" ng-click="showDocumentPopup('emr')">Send to EMR</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Loader -->
                    <div class="loader" ng-show="isLoading" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1000;">
                        <div class="spinner" style="border: 8px solid #f3f3f3; border-top: 8px solid #3498db; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite;"></div>
                    </div>

                    <!-- Patient Section -->
                    <div class="patient-section">
                        <div class="patient-avatar">
                            <div class="avatar-icon">👤</div>
                        </div>
                        <div class="patient-info">
                            <div class="info-header">
                                <span class="edit-icon" ng-click="toggleEdit('patient')" ng-show="!isEditing['patient']">✏️</span>
                                <button class="save-btn" ng-show="isEditing['patient']" ng-click="saveAllPatientInfo()">Save</button>
                            </div>
                            <div class="info-grid">
                                <div class="info-field">
                                    <span class="info-label">Name:</span>
                                    <input type="text" ng-model="uiFields.name" ng-show="isEditing['patient']" placeholder="Enter name" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.name"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Gender:</span>
                                    <select ng-model="uiFields.gender" ng-show="isEditing['patient']">
                                        <option value="">Select Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.gender || 'Not specified'"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Blood Pressure:</span>
                                    <input type="text" ng-model="uiFields.bloodPressure" ng-show="isEditing['patient']" placeholder="Enter BP" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.bloodPressure"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Age:</span>
                                    <input type="number" ng-model="uiFields.age" ng-show="isEditing['patient']" placeholder="Enter age" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.age"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Temperature:</span>
                                    <input type="text" ng-model="uiFields.temperature" ng-show="isEditing['patient']" placeholder="Enter temperature" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.temperature"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Weight:</span>
                                    <input type="text" ng-model="uiFields.weight" ng-show="isEditing['patient']" placeholder="Enter weight" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.weight"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Oxygen Level:</span>
                                    <input type="text" ng-model="uiFields.oxygenLevel" ng-show="isEditing['patient']" placeholder="Enter oxygen level" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.oxygenLevel"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Height:</span>
                                    <input type="text" ng-model="uiFields.height" ng-show="isEditing['patient']" placeholder="Enter height" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.height"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Date:</span>
                                    <input type="date" ng-model="uiFields.date" ng-show="isEditing['patient']" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.date"></div>
                                </div>
                                <div class="info-field">
                                    <span class="info-label">Time:</span>
                                    <input type="time" ng-model="uiFields.time" ng-show="isEditing['patient']" />
                                    <div class="info-value" ng-show="!isEditing['patient']" ng-bind="uiFields.time"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Past Medical History, Allergies, and Reason for Visit -->
                    <div class="section">
                        <div class="paten-grid">
                            <div class="separate-section" ng-init="isEditing['medicalInfo'] = false">
                                <div class="info-header">
                                    <span class="edit-icon" ng-click="toggleEdit('medicalInfo')" ng-show="!isEditing['medicalInfo']">✏️</span>
                                    <button class="save-btn" ng-show="isEditing['medicalInfo']" ng-click="saveMedicalInfo()">Save</button>
                                </div>
                                <div class="history-field" ng-show="isEditing['medicalInfo']">
                                    <div class="info-field">
                                        <span class="info-label">Past Medical History:</span>
                                        <input type="text" ng-model="uiFields.medicalHistory" placeholder="Enter medical history" class="info-input" />
                                    </div>
                                    <div class="info-field">
                                        <span class="info-label">Allergies:</span>
                                        <input type="text" ng-model="uiFields.allergies" placeholder="Enter allergies" class="info-input" />
                                    </div>
                                    <div class="info-field">
                                        <span class="info-label">Reason for Visit:</span>
                                        <input type="text" ng-model="uiFields.reasonForVisit" placeholder="Enter reason for visit" class="info-input" />
                                    </div>
                                </div>
                                <div class="history-field" ng-show="!isEditing['medicalInfo']">
                                    <div class="info-field">
                                        <span class="info-label">Past Medical History:</span>
                                        <div class="history-value" ng-bind="uiFields.medicalHistory || 'Not specified'"></div>
                                    </div>
                                    <div class="info-field">
                                        <span class="info-label">Allergies:</span>
                                        <div class="history-value align" ng-bind="uiFields.allergies || 'Not specified'"></div>
                                    </div>
                                    <div class="info-field">
                                        <span class="info-label">Reason for Visit:</span>
                                        <div class="history-value align" ng-bind="uiFields.reasonForVisit || 'Not specified'"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SOAP Notes Section -->
                    <div class="section">
                        <h2 class="section-title soap-title">SOAP Notes</h2>
                        <div class="soap-grid">
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title">Subjective</span>
                                    <span class="edit-icon" ng-click="toggleEdit('soap.subjective')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['soap.subjective']" ng-bind="uiFields.subjective"></div>
                                <div class="card-content" ng-show="isEditing['soap.subjective']">
                                    <textarea ng-model="uiFields.subjective" placeholder="Enter subjective notes"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('soap.subjective')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title">Objective</span>
                                    <span class="edit-icon" ng-click="toggleEdit('soap.objective')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['soap.objective']" ng-bind="uiFields.objective"></div>
                                <div class="card-content" ng-show="isEditing['soap.objective']">
                                    <textarea ng-model="uiFields.objective" placeholder="Enter objective notes"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('soap.objective')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title">Assessment</span>
                                    <span class="edit-icon" ng-click="toggleEdit('soap.assessment')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['soap.assessment']" ng-bind="uiFields.assessment"></div>
                                <div class="card-content" ng-show="isEditing['soap.assessment']">
                                    <textarea ng-model="uiFields.assessment" placeholder="Enter assessment notes"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('soap.assessment')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title">Plan</span>
                                    <span class="edit-icon" ng-click="toggleEdit('soap.plan')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['soap.plan']" ng-bind="uiFields.plan"></div>
                                <div class="card-content" ng-show="isEditing['soap.plan']">
                                    <textarea ng-model="uiFields.plan" placeholder="Enter plan notes"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('soap.plan')">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Diagnostic Section -->
                    <div class="section">
                        <h2 class="section-title diagnostic-title">Diagnostic</h2>
                        <div class="diagnostic-grid">
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Primary Diagnosis</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.primaryDiagnosis')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.primaryDiagnosis']">
                                    <ul>
                                        <li ng-bind="uiFields.primaryDiagnosis || 'Not specified'"></li>
                                    </ul>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.primaryDiagnosis']">
                                    <textarea ng-model="uiFields.primaryDiagnosis" placeholder="Enter primary diagnosis"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.primaryDiagnosis')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Differential Diagnosis</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.differentialDiagnoses')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.differentialDiagnoses']">
                                    <ul ng-if="uiFields.differentialDiagnoses && uiFields.differentialDiagnoses.length">
                                        <li ng-repeat="diff in uiFields.differentialDiagnoses track by $index" ng-bind="'- ' + diff.diagnosis + ': ' + diff.justification"></li>
                                    </ul>
                                    <div ng-if="uiFields.differentialDiagnoses && !uiFields.differentialDiagnoses.length">No differential diagnoses specified</div>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.differentialDiagnoses']">
                                    <div ng-repeat="diff in uiFields.differentialDiagnoses track by $index">
                                        <input type="text" ng-model="diff.diagnosis" placeholder="Diagnosis" />
                                        <input type="text" ng-model="diff.justification" placeholder="Justification" />
                                        <button class="action-btn" ng-click="uiFields.differentialDiagnoses.splice($index, 1)">Remove</button>
                                    </div>
                                    <button class="action-btn" ng-click="uiFields.differentialDiagnoses.push({ diagnosis: '', justification: '' })">Add Diagnosis</button>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.differentialDiagnoses')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Clinical Rationale</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.clinicalRationale')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.clinicalRationale']">
                                    <ul>
                                        <li ng-bind="uiFields.clinicalRationale || 'Not specified'"></li>
                                    </ul>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.clinicalRationale']">
                                    <textarea ng-model="uiFields.clinicalRationale" placeholder="Enter clinical rationale"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.clinicalRationale')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Next Recommended Steps</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.nextSteps')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.nextSteps']">
                                    <ul ng-if="uiFields.nextStepsList && uiFields.nextStepsList.length">
                                        <li ng-repeat="step in uiFields.nextStepsList track by $index" ng-bind="'- ' + step"></li>
                                    </ul>
                                    <div ng-if="!uiFields.nextStepsList || !uiFields.nextStepsList.length">No next steps specified</div>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.nextSteps']">
                                    <textarea ng-model="uiFields.nextSteps" placeholder="Enter next steps"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.nextSteps')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Red Flags</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.redFlags')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.redFlags']">
                                    <ul>
                                        <li ng-bind="uiFields.redFlags || 'Not specified'"></li>
                                    </ul>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.redFlags']">
                                    <textarea ng-model="uiFields.redFlags" placeholder="Enter red flags"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.redFlags')">Save</button>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Urgency Level</span>
                                    <span class="edit-icon" ng-click="toggleEdit('diagnostic.urgencyLevel')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['diagnostic.urgencyLevel']">
                                    <ul>
                                        <li ng-bind="uiFields.urgencyLevel || 'Not specified'"></li>
                                    </ul>
                                </div>
                                <div class="card-content" ng-show="isEditing['diagnostic.urgencyLevel']">
                                    <textarea ng-model="uiFields.urgencyLevel" placeholder="Enter urgency level"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('diagnostic.urgencyLevel')">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Coding Summary Section -->
                    <div class="section">
                        <h2 class="section-title coding-title">Coding Summary</h2>
                        <div class="coding-grid">
                            <div class="card coding-card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Diagnosis Codes</span>
                                    <span class="edit-icon" ng-click="toggleEdit('coding.diagnosisCodes')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['coding.diagnosisCodes']">
                                    <div class="coding-text">Primary Diagnostic (ICD 10):</div>
                                    <div>{{uiFields.primaryDiagnosisCode}}</div>
                                    <div class="coding-text">Secondary Diagnosis (ICD 10):</div>
                                    <div>{{uiFields.secondaryDiagnosisCode}}</div>
                                </div>
                                <div class="card-content" ng-show="isEditing['coding.diagnosisCodes']">
                                    <div class="coding-text">Primary Diagnostic (ICD 10):</div>
                                    <textarea ng-model="uiFields.primaryDiagnosisCode" placeholder="Enter primary diagnosis code"></textarea>
                                    <div class="coding-text">Secondary Diagnosis (ICD 10):</div>
                                    <textarea ng-model="uiFields.secondaryDiagnosisCode" placeholder="Enter secondary diagnosis code"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('coding.diagnosisCodes')">Save</button>
                                </div>
                            </div>
                            <div class="card coding-card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Procedure Codes</span>
                                    <span class="edit-icon" ng-click="toggleEdit('coding.procedureCodes')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['coding.procedureCodes']" ng-bind="uiFields.procedureCodes"></div>
                                <div class="card-content" ng-show="isEditing['coding.procedureCodes']">
                                    <textarea ng-model="uiFields.procedureCodes" placeholder="Enter procedure codes"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('coding.procedureCodes')">Save</button>
                                </div>
                            </div>
                            <div class="card coding-card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Prior Authorization Package</span>
                                    <span class="edit-icon" ng-click="toggleEdit('coding.priorAuthorization')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['coding.priorAuthorization']" ng-bind="uiFields.priorAuthorization"></div>
                                <div class="card-content" ng-show="isEditing['coding.priorAuthorization']">
                                    <textarea ng-model="uiFields.priorAuthorization" placeholder="Enter prior authorization package"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('coding.priorAuthorization')">Save</button>
                                </div>
                            </div>
                            <div class="card coding-card">
                                <div class="card-header">
                                    <span class="card-title diagnostic-card-title">Supporting Documentation</span>
                                    <span class="edit-icon" ng-click="toggleEdit('coding.supportingDocumentation')">✏️</span>
                                </div>
                                <div class="card-content" ng-show="!isEditing['coding.supportingDocumentation']" ng-bind="uiFields.supportingDocumentation"></div>
                                <div class="card-content" ng-show="isEditing['coding.supportingDocumentation']">
                                    <textarea ng-model="uiFields.supportingDocumentation" placeholder="Enter supporting documentation"></textarea>
                                    <button class="save-btn" ng-click="saveEdit('coding.supportingDocumentation')">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bottom Actions -->
                    <div class="bottom-actions">
                        <button class="action-btn" ng-click="downloadAsPDF()">Save as PDF</button>
                        <button class="action-btn" ng-click="showDocumentPopup('save')">Save as Word Document</button>
                        <button class="action-btn" ng-click="showDocumentPopup('email')">Email to Me</button>
                        <button class="action-btn" ng-click="showDocumentPopup('emr')">Send to EMR</button>
                    </div>

                    <!-- Popup for Save/Email -->
                    <div class="popup" ng-show="showPopup">
                        <div class="popup-content">
                            <h2>{{popupTitle}}</h2>
                            <div class="document-preview">
                                <h3>Patient Information</h3>
                                <p>Name: {{uiFields.name}}</p>
                                <p>Gender: {{uiFields.gender || 'Not specified'}}</p>
                                <p>Age: {{uiFields.age}}</p>
                                <p>Weight: {{uiFields.weight}}</p>
                                <p>Height: {{uiFields.height}}</p>
                                <p>Blood Pressure: {{uiFields.bloodPressure}}</p>
                                <p>Temperature: {{uiFields.temperature}}</p>
                                <p>Oxygen Level: {{uiFields.oxygenLevel}}</p>
                                <p>Date: {{uiFields.date || 'Not specified'}}</p>
                                <p>Time: {{uiFields.time || 'Not specified'}}</p>
                                <p>Past Medical History: {{uiFields.medicalHistory}}</p>
                                <p>Allergies: {{uiFields.allergies}}</p>
                                <p>Reason for Visit: {{uiFields.reasonForVisit || 'Not specified'}}</p>

                                <h3>SOAP Notes</h3>
                                <p>Subjective: {{uiFields.subjective}}</p>
                                <p>Objective: {{uiFields.objective}}</p>
                                <p>Assessment: {{uiFields.assessment}}</p>
                                <p>Plan: {{uiFields.plan}}</p>

                                <h3>Diagnostic</h3>
                                <p>Primary Diagnosis: {{uiFields.primaryDiagnosis}}</p>
                                <p>Differential Diagnosis:
                                    <span ng-if="uiFields.differentialDiagnoses && uiFields.differentialDiagnoses.length">
                                        <span ng-repeat="diff in uiFields.differentialDiagnoses track by $index">- {{diff.diagnosis}}: {{diff.justification}}<br></span>
                                    </span>
                                    <span ng-if="!uiFields.differentialDiagnoses || !uiFields.differentialDiagnoses.length">No differential diagnoses specified</span>
                                </p>
                                <p>Clinical Rationale: {{uiFields.clinicalRationale}}</p>
                                <p>Next Steps:
                                    <span ng-if="uiFields.nextStepsList && uiFields.nextStepsList.length">
                                        <span ng-repeat="step in uiFields.nextStepsList track by $index">- {{step}}<br></span>
                                    </span>
                                    <span ng-if="!uiFields.nextStepsList || !uiFields.nextStepsList.length">No next steps specified</span>
                                </p>
                                <p>Red Flags: {{uiFields.redFlags}}</p>
                                <p>Urgency Level: {{uiFields.urgencyLevel}}</p>

                                <h3>Coding Summary1</h3>
                                <p>Primary Diagnosis Code: {{uiFields.primaryDiagnosisCode}}</p>
                                <p>Secondary Diagnosis Code: {{uiFields.secondaryDiagnosisCode || 'Not specified'}}</p>
                                <p>Procedure Codes: {{uiFields.procedureCodes || 'Not specified'}}</p>
                                <p>Prior Authorization: {{uiFields.priorAuthorization || 'Not specified'}}</p>
                                <p>Supporting Documentation: {{uiFields.supportingDocumentation}}</p>
                            </div>
                            <div class="popup-actions">
                                <button class="action-btn" ng-click="handlePopupAction('save')">Save</button>
                                <button class="action-btn" ng-click="handlePopupAction('email')">Email</button>
                                <button class="action-btn" ng-click="handlePopupAction('cancel')">Cancel</button>
                            </div>
                        </div>
                    </div>

                    <!-- Popup for Recording -->
                    <div class="popup" ng-show="showRecordingPopupFlag">
                        <div class="popup-content">
                            <h2>Record Audio</h2>
                            <div class="recording-status">
                                <p ng-if="!isRecording">Ready to record</p>
                                <p ng-if="isRecording">Recording...</p>
                            </div>
                            <canvas id="waveform" width="530" height="100"></canvas>
                            <div class="popup-actions">
                                <button class="action-btn" ng-click="startRecording()" ng-disabled="isRecording || isUploading">Start Recording</button>
                                <button class="action-btn" ng-click="stopRecording()" ng-disabled="!isRecording || isUploading">Stop Recording</button>
                                <button class="action-btn" ng-click="saveRecording()" ng-disabled="isRecording || !audioBlob || isUploading">Save</button>
                                <button class="action-btn" ng-click="uploadAudio()" ng-disabled="isRecording || isUploading">Audio Upload</button>
                                <button class="action-btn" ng-click="cancelRecording()" ng-disabled="isUploading">Cancel</button>
                                <div class="loader" ng-show="isLoading">
                                    <div class="spinner"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `,
            controller: 'MainController'
        })
        .otherwise({
            redirectTo: '/users'
        });
}]);
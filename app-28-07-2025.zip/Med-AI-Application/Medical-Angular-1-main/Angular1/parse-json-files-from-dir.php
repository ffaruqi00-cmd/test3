<?php
// Set the Content-Type header to application/json.
// This tells the client (AngularJS) that the response body is JSON.
header('Content-Type: application/json');

// --- CORS Configuration ---
// IMPORTANT: For development, you can use '*' to allow all origins.
// For production, replace '*' with the specific domain(s) where your Angular app is hosted.
// Example: header('Access-Control-Allow-Origin: https://your-angular-app-domain.com');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight OPTIONS requests (common with CORS for non-simple requests)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0); // Respond to preflight requests and exit
}

// Initialize an empty array for the response data, setting a default error state
$response_data = [
    'status' => 'error',
    'message' => 'An unknown error occurred.'
];

// Get user ID from GET parameters (e.g. ?user_id=123)
// Using basename for initial sanitization, but further validation is crucial.
$userId = isset($_GET['user_id']) ? basename($_GET['user_id']) : null;

// --- User ID Validation ---
// This regex ensures the user ID is purely numeric, which is ideal for a directory name.
// It's a stronger validation than just basename if user IDs are always integers.
if (!$userId || !preg_match('/^\d+$/', $userId)) {
    http_response_code(400); // Bad Request
    $response_data['message'] = 'Invalid or missing user ID.';
    echo json_encode($response_data);
    exit;
}

$targetUserDir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'RequestedFileDir' . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . $userId

// Check if the user-specific directory exists
if (!is_dir($targetUserDir)) {
    http_response_code(404); // Not Found
    $response_data['message'] = 'User folder not found or not accessible at: ' . $targetUserDir;
    echo json_encode($response_data);
    exit;
}

// Find all JSON files within the user's directory
$files = glob($targetUserDir . '*.json');
$result = [];

// Iterate through found files, read content, decode JSON, and collect relevant data
foreach ($files as $file) {
    // Ensure the file exists and is readable before attempting to read
    if (file_exists($file) && is_readable($file)) {
        $content = file_get_contents($file);
        $json = json_decode($content, true); // Decode as associative array

        // Check for JSON decoding errors and ensure the 'name' key exists
        if (json_last_error() === JSON_ERROR_NONE && isset($json['name'])) {
            $result[] = [
                'filename' => basename($file), // Just the file name, not the full path
                'name' => $json['Name']
            ];
        } else {
            // Log JSON parsing errors for debugging, but don't expose them in the response.
            error_log("Invalid JSON or missing 'name' in file: " . basename($file) . " for user_id: " . $userId . ". Error: " . json_last_error_msg());
            // Optionally, you could include a warning in the response for this specific file,
            // but generally, you want to return valid data and log issues internally.
        }
    } else {
        // Log if a file found by glob is not readable (shouldn't happen often, but good for robustness)
        error_log("File not found or not readable during glob iteration: " . $file);
    }
}

// If no files were processed, but the directory existed, you might want a different status
if (empty($result) && is_dir($targetUserDir)) {
    $response_data['status'] = 'success'; // Or 'warning' if expected behavior for no files
    $response_data['message'] = 'No valid JSON files found in user folder or no files with a "name" key.';
    $response_data['data'] = []; // Ensure data is an empty array
} else {
    // Successfully processed files
    $response_data['status'] = 'success';
    $response_data['message'] = 'Successfully retrieved JSON data.';
    $response_data['data'] = $result;
}

// Encode the final response data into JSON format and output it.
echo json_encode($response_data);

?>
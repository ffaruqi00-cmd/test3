<?php
// Enable error reporting (optional for debugging)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// CORS headers for frontend communication
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Only handle POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Check file upload
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'File not uploaded']);
    exit;
}

// Recipient email (from frontend or fallback)
$recipient = $_POST['email'] ?? 'iabubakardev@gmail.com';
$file = $_FILES['file'];
$filePath = $file['tmp_name'];
$fileName = $file['name'];

// Include PHPMailer
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'abubakarblogger@gmail.com'; // Your Gmail address
    $mail->Password = 'cacpgvsxsucpzasc';    // Gmail App Password
    $mail->SMTPSecure = 'tls';                // Or 'ssl'
    $mail->Port = 587;                        // 465 for SSL

    // Email content
    $mail->setFrom('abubakarblogger@gmail.com', 'Healthcare System');
    $mail->addAddress($recipient);
    $mail->Subject = 'Medical Report';
    $mail->Body = 'Attached is your medical report.';

    // Attachment
    $mail->addAttachment($filePath, $fileName);

    // Send email
    $mail->send();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $mail->ErrorInfo,
        'exception' => $e->getMessage()
    ]);
}
